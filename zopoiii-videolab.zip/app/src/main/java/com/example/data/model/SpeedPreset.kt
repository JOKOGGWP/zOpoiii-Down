package com.example.data.model

enum class SpeedPreset(val displayName: String, val baseSpeed: Float) {
    NORMAL("Normal 1.0x", 1.0f),
    MONTAGE("Montage (Cepat-Lambat)", 1.5f),
    HERO("Hero (Dramatic Slow)", 0.5f),
    BULLET("Bullet Time", 0.25f),
    JUMP_CUT("Fast Jump 2.0x", 2.0f);

    companion object {
        val standardSpeeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f, 4.0f)
    }
}
