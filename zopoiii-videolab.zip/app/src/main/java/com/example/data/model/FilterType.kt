package com.example.data.model

import androidx.compose.ui.graphics.ColorMatrix

enum class FilterType(val displayName: String) {
    ORIGINAL("Asli"),
    VIVID("Vivid"),
    WARM("Hangat"),
    COOL("Sejuk"),
    CINEMA("Sinema"),
    VINTAGE("Vintage"),
    MONO("Mono"),
    NOIR("Noir"),
    RETRO("Retro");

    fun getColorMatrix(): ColorMatrix {
        return when (this) {
            ORIGINAL -> ColorMatrix()
            VIVID -> ColorMatrix().apply {
                setToSaturation(1.4f)
            }
            WARM -> ColorMatrix(
                floatArrayOf(
                    1.15f, 0f, 0f, 0f, 15f,
                    0f, 1.05f, 0f, 0f, 5f,
                    0f, 0f, 0.90f, 0f, -10f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            COOL -> ColorMatrix(
                floatArrayOf(
                    0.90f, 0f, 0f, 0f, -10f,
                    0f, 1.02f, 0f, 0f, 0f,
                    0f, 0f, 1.20f, 0f, 20f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            CINEMA -> ColorMatrix(
                floatArrayOf(
                    1.1f, 0f, 0f, 0f, -5f,
                    0f, 1.0f, 0f, 0f, 5f,
                    0f, 0f, 1.15f, 0f, 15f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            VINTAGE -> ColorMatrix(
                floatArrayOf(
                    0.9f, 0.1f, 0.1f, 0f, 20f,
                    0.1f, 0.8f, 0.1f, 0f, 10f,
                    0.1f, 0.1f, 0.6f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            MONO -> ColorMatrix().apply {
                setToSaturation(0f)
            }
            NOIR -> ColorMatrix(
                floatArrayOf(
                    0.4f, 0.4f, 0.4f, 0f, -25f,
                    0.4f, 0.4f, 0.4f, 0f, -25f,
                    0.4f, 0.4f, 0.4f, 0f, -25f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            RETRO -> ColorMatrix(
                floatArrayOf(
                    1.2f, 0.05f, 0f, 0f, 10f,
                    0.05f, 1.1f, 0.05f, 0f, 10f,
                    0f, 0.05f, 0.8f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        }
    }
}
