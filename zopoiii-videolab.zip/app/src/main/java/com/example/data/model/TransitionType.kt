package com.example.data.model

enum class TransitionType(val displayName: String) {
    NONE("Tanpa Transisi"),
    FADE("Fade Hitam"),
    CROSS_DISSOLVE("Dissolve"),
    SLIDE_LEFT("Geser Kiri"),
    SLIDE_RIGHT("Geser Kanan"),
    SLIDE_UP("Geser Atas"),
    SLIDE_DOWN("Geser Bawah"),
    ZOOM("Zoom"),
    BLUR("Blur"),
    WIPE("Wipe");

    companion object {
        val durationsMs = listOf(100L, 300L, 500L, 1000L, 2000L)
        fun fromName(name: String): TransitionType {
            return entries.firstOrNull { it.name == name } ?: NONE
        }
    }
}
