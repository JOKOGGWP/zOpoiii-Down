package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.database.dao.ProjectDao
import com.example.data.database.entities.*

@Database(
    entities = [
        ProjectEntity::class,
        TrackEntity::class,
        MediaEntity::class,
        ClipEntity::class,
        AudioClipEntity::class,
        TextClipEntity::class,
        StickerEntity::class,
        ShapeEntity::class,
        EffectEntity::class,
        KeyframeEntity::class,
        TransitionEntity::class,
        MarkerEntity::class,
        SubtitleEntity::class,
        ExportJobEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class VideoLabDatabase : RoomDatabase() {

    abstract fun projectDao(): ProjectDao

    companion object {
        @Volatile
        private var INSTANCE: VideoLabDatabase? = null

        fun getInstance(context: Context): VideoLabDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VideoLabDatabase::class.java,
                    "zopoiii_videolab.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
