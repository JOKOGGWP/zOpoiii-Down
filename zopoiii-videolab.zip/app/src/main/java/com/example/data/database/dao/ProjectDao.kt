package com.example.data.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.database.entities.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {

    // --- Projects ---
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :projectId LIMIT 1")
    suspend fun getProjectById(projectId: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity)

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :projectId")
    suspend fun deleteProjectById(projectId: String)

    // --- Media ---
    @Query("SELECT * FROM media WHERE projectId = :projectId")
    suspend fun getMediaForProject(projectId: String): List<MediaEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedia(media: List<MediaEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSingleMedia(media: MediaEntity)

    // --- Tracks ---
    @Query("SELECT * FROM tracks WHERE projectId = :projectId ORDER BY orderIndex ASC")
    suspend fun getTracksForProject(projectId: String): List<TrackEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTracks(tracks: List<TrackEntity>)

    // --- Clips ---
    @Query("SELECT * FROM clips WHERE projectId = :projectId ORDER BY orderIndex ASC")
    suspend fun getClipsForProject(projectId: String): List<ClipEntity>

    @Query("SELECT * FROM clips WHERE projectId = :projectId ORDER BY orderIndex ASC")
    fun getClipsFlowForProject(projectId: String): Flow<List<ClipEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClips(clips: List<ClipEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClip(clip: ClipEntity)

    @Update
    suspend fun updateClip(clip: ClipEntity)

    @Query("DELETE FROM clips WHERE id = :clipId")
    suspend fun deleteClipById(clipId: String)

    @Query("DELETE FROM clips WHERE projectId = :projectId")
    suspend fun deleteClipsByProjectId(projectId: String)

    // --- Text Clips ---
    @Query("SELECT * FROM text_clips WHERE projectId = :projectId ORDER BY startTimeMs ASC")
    suspend fun getTextClipsForProject(projectId: String): List<TextClipEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTextClips(textClips: List<TextClipEntity>)

    @Query("DELETE FROM text_clips WHERE id = :textClipId")
    suspend fun deleteTextClipById(textClipId: String)

    @Query("DELETE FROM text_clips WHERE projectId = :projectId")
    suspend fun deleteTextClipsByProjectId(projectId: String)

    // --- Audio Clips ---
    @Query("SELECT * FROM audio_clips WHERE projectId = :projectId ORDER BY startTimeMs ASC")
    suspend fun getAudioClipsForProject(projectId: String): List<AudioClipEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudioClips(audioClips: List<AudioClipEntity>)

    @Query("DELETE FROM audio_clips WHERE id = :audioClipId")
    suspend fun deleteAudioClipById(audioClipId: String)

    @Query("DELETE FROM audio_clips WHERE projectId = :projectId")
    suspend fun deleteAudioClipsByProjectId(projectId: String)

    // --- Transitions ---
    @Query("SELECT * FROM transitions WHERE projectId = :projectId")
    suspend fun getTransitionsForProject(projectId: String): List<TransitionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransitions(transitions: List<TransitionEntity>)

    @Query("DELETE FROM transitions WHERE projectId = :projectId")
    suspend fun deleteTransitionsByProjectId(projectId: String)

    // --- Markers ---
    @Query("SELECT * FROM markers WHERE projectId = :projectId ORDER BY timestampMs ASC")
    suspend fun getMarkersForProject(projectId: String): List<MarkerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarker(marker: MarkerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarkers(markers: List<MarkerEntity>)

    @Query("DELETE FROM markers WHERE id = :markerId")
    suspend fun deleteMarkerById(markerId: String)

    @Query("DELETE FROM markers WHERE projectId = :projectId")
    suspend fun deleteMarkersByProjectId(projectId: String)

    // --- Subtitles ---
    @Query("SELECT * FROM subtitles WHERE projectId = :projectId ORDER BY startMs ASC")
    suspend fun getSubtitlesForProject(projectId: String): List<SubtitleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubtitles(subtitles: List<SubtitleEntity>)

    @Query("DELETE FROM subtitles WHERE id = :subtitleId")
    suspend fun deleteSubtitleById(subtitleId: String)

    @Query("DELETE FROM subtitles WHERE projectId = :projectId")
    suspend fun deleteSubtitlesByProjectId(projectId: String)

    // --- Stickers ---
    @Query("SELECT * FROM stickers WHERE projectId = :projectId ORDER BY startTimeMs ASC")
    suspend fun getStickersForProject(projectId: String): List<StickerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStickers(stickers: List<StickerEntity>)

    @Query("DELETE FROM stickers WHERE id = :stickerId")
    suspend fun deleteStickerById(stickerId: String)

    @Query("DELETE FROM stickers WHERE projectId = :projectId")
    suspend fun deleteStickersByProjectId(projectId: String)

    // --- Shapes ---
    @Query("SELECT * FROM shapes WHERE projectId = :projectId ORDER BY startTimeMs ASC")
    suspend fun getShapesForProject(projectId: String): List<ShapeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShapes(shapes: List<ShapeEntity>)

    @Query("DELETE FROM shapes WHERE id = :shapeId")
    suspend fun deleteShapeById(shapeId: String)

    @Query("DELETE FROM shapes WHERE projectId = :projectId")
    suspend fun deleteShapesByProjectId(projectId: String)

    // --- Export Jobs ---
    @Query("SELECT * FROM export_jobs ORDER BY createdAt DESC")
    fun getAllExportJobs(): Flow<List<ExportJobEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExportJob(job: ExportJobEntity)

    @Update
    suspend fun updateExportJob(job: ExportJobEntity)

    @Query("DELETE FROM export_jobs WHERE id = :jobId")
    suspend fun deleteExportJobById(jobId: String)

    // --- Full Project Sync Transaction ---
    @Transaction
    suspend fun saveFullProject(
        project: ProjectEntity,
        mediaList: List<MediaEntity>,
        clips: List<ClipEntity>,
        textClips: List<TextClipEntity>,
        audioClips: List<AudioClipEntity>,
        transitions: List<TransitionEntity>,
        markers: List<MarkerEntity> = emptyList(),
        subtitles: List<SubtitleEntity> = emptyList()
    ) {
        insertProject(project)
        if (mediaList.isNotEmpty()) {
            insertMedia(mediaList)
        }
        deleteClipsByProjectId(project.id)
        if (clips.isNotEmpty()) {
            insertClips(clips)
        }
        deleteTextClipsByProjectId(project.id)
        if (textClips.isNotEmpty()) {
            insertTextClips(textClips)
        }
        deleteAudioClipsByProjectId(project.id)
        if (audioClips.isNotEmpty()) {
            insertAudioClips(audioClips)
        }
        deleteTransitionsByProjectId(project.id)
        if (transitions.isNotEmpty()) {
            insertTransitions(transitions)
        }
        deleteMarkersByProjectId(project.id)
        if (markers.isNotEmpty()) {
            insertMarkers(markers)
        }
        deleteSubtitlesByProjectId(project.id)
        if (subtitles.isNotEmpty()) {
            insertSubtitles(subtitles)
        }
    }
}
