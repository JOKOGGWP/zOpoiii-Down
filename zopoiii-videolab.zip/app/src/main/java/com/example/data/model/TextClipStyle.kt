package com.example.data.model

data class TextClipStyle(
    val id: String,
    val text: String,
    val fontName: String = "Roboto",
    val sizeSp: Float = 22f,
    val colorHex: Long = 0xFFFFFFFF,
    val strokeColorHex: Long = 0xFF000000,
    val hasStroke: Boolean = true,
    val hasShadow: Boolean = true,
    val backgroundColorHex: Long = 0x00000000,
    val positionX: Float = 0.5f, // 0.0 - 1.0 (relative to canvas width)
    val positionY: Float = 0.75f, // 0.0 - 1.0 (relative to canvas height)
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f,
    val startTimeMs: Long = 0L,
    val durationMs: Long = 3000L,
    val animation: TextAnimation = TextAnimation.POP
)

enum class TextAnimation(val displayName: String) {
    NONE("Tanpa Animasi"),
    FADE_IN("Fade In"),
    FADE_OUT("Fade Out"),
    POP("Pop Up"),
    SLIDE_UP("Slide Up"),
    SLIDE_DOWN("Slide Down"),
    ZOOM("Zoom In"),
    TYPEWRITER("Typewriter")
}
