package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.database.dao.ProjectDao
import com.example.data.database.entities.AudioClipEntity
import com.example.data.database.entities.ClipEntity
import com.example.data.database.entities.MediaEntity
import com.example.data.database.entities.ProjectEntity
import com.example.data.database.entities.TextClipEntity
import com.example.data.database.entities.TrackEntity
import com.example.data.database.entities.TransitionEntity
import com.example.data.model.CanvasAspectRatio
import com.example.data.model.FullProjectData
import com.example.media.MediaUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ProjectRepository(
    private val projectDao: ProjectDao,
    private val context: Context
) {
    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    suspend fun getProjectById(projectId: String): ProjectEntity? = withContext(Dispatchers.IO) {
        projectDao.getProjectById(projectId)
    }

    suspend fun loadFullProject(projectId: String): FullProjectData? = withContext(Dispatchers.IO) {
        val project = projectDao.getProjectById(projectId) ?: return@withContext null
        val media = projectDao.getMediaForProject(projectId)
        val clips = projectDao.getClipsForProject(projectId)
        val textClips = projectDao.getTextClipsForProject(projectId)
        val audioClips = projectDao.getAudioClipsForProject(projectId)
        val transitions = projectDao.getTransitionsForProject(projectId)
        val markers = projectDao.getMarkersForProject(projectId)
        val subtitles = projectDao.getSubtitlesForProject(projectId)
        val stickers = projectDao.getStickersForProject(projectId)
        val shapes = projectDao.getShapesForProject(projectId)

        var hasModifiedMedia = false
        val healedMedia = media.map { m ->
            if (!MediaUtils.isUriReadable(context, m.uri)) {
                hasModifiedMedia = true
                val safeFile = MediaUtils.getSafeMediaFile(context, projectId, m.id)
                m.copy(uri = Uri.fromFile(safeFile).toString())
            } else {
                m
            }
        }

        if (hasModifiedMedia) {
            projectDao.insertMedia(healedMedia)
        }

        FullProjectData(
            project = project,
            mediaList = healedMedia,
            clips = clips,
            textClips = textClips,
            audioClips = audioClips,
            transitions = transitions,
            markers = markers,
            subtitles = subtitles,
            stickers = stickers,
            shapes = shapes
        )
    }

    suspend fun createNewProject(
        name: String,
        mediaUris: List<Uri>,
        canvasRatio: CanvasAspectRatio
    ): String = withContext(Dispatchers.IO) {
        val projectId = UUID.randomUUID().toString()
        var currentStartTime = 0L
        val mediaList = mutableListOf<MediaEntity>()
        val clipsList = mutableListOf<ClipEntity>()
        var firstThumbPath: String? = null

        // Canvas dimensions based on aspect ratio
        val (cWidth, cHeight) = when (canvasRatio) {
            CanvasAspectRatio.RATIO_9_16 -> 1080 to 1920
            CanvasAspectRatio.RATIO_16_9 -> 1920 to 1080
            CanvasAspectRatio.RATIO_1_1 -> 1080 to 1080
            CanvasAspectRatio.RATIO_4_3 -> 1440 to 1080
            CanvasAspectRatio.RATIO_3_4 -> 1080 to 1440
            CanvasAspectRatio.RATIO_21_9 -> 2560 to 1080
            CanvasAspectRatio.RATIO_9_21 -> 1080 to 2560
            CanvasAspectRatio.RATIO_2_1 -> 2160 to 1080
            CanvasAspectRatio.RATIO_1_2 -> 1080 to 2160
            CanvasAspectRatio.CUSTOM -> 1080 to 1920
            else -> 1080 to 1920
        }

        mediaUris.forEachIndexed { index, rawUri ->
            val localUri = MediaUtils.importMediaToProject(context, projectId, rawUri)
            val meta = MediaUtils.extractMetadata(context, localUri)
            val mediaId = UUID.randomUUID().toString()
            if (firstThumbPath == null && meta.thumbnailPath != null) {
                firstThumbPath = meta.thumbnailPath
            }

            val mediaEntity = MediaEntity(
                id = mediaId,
                projectId = projectId,
                uri = localUri.toString(),
                type = if (meta.isVideo) "video" else "image",
                durationMs = meta.durationMs,
                width = meta.width,
                height = meta.height,
                rotation = meta.rotation
            )
            mediaList.add(mediaEntity)

            val clipId = UUID.randomUUID().toString()
            val clipEntity = ClipEntity(
                id = clipId,
                projectId = projectId,
                mediaId = mediaId,
                trackId = "track_main_video",
                orderIndex = index,
                startTimeMs = currentStartTime,
                durationMs = meta.durationMs,
                sourceStartMs = 0L,
                sourceEndMs = meta.durationMs,
                positionX = 0.5f,
                positionY = 0.5f,
                scaleX = 1.0f,
                scaleY = 1.0f,
                rotation = 0f,
                opacity = 1.0f,
                volume = 1.0f,
                speed = 1.0f,
                filterName = "ORIGINAL"
            )
            clipsList.add(clipEntity)
            currentStartTime += meta.durationMs
        }

        val projectEntity = ProjectEntity(
            id = projectId,
            name = name.ifBlank { "Proyek ${System.currentTimeMillis() % 10000}" },
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            canvasWidth = cWidth,
            canvasHeight = cHeight,
            canvasRatio = canvasRatio.label,
            thumbnailPath = firstThumbPath,
            totalDurationMs = currentStartTime
        )

        val defaultTrack = TrackEntity(
            id = "track_main_video",
            projectId = projectId,
            type = "video",
            orderIndex = 0
        )

        projectDao.insertProject(projectEntity)
        projectDao.insertTracks(listOf(defaultTrack))
        if (mediaList.isNotEmpty()) {
            projectDao.insertMedia(mediaList)
            projectDao.insertClips(clipsList)
        }

        projectId
    }

    suspend fun saveFullProject(data: FullProjectData) = withContext(Dispatchers.IO) {
        val updatedProject = data.project.copy(
            updatedAt = System.currentTimeMillis(),
            totalDurationMs = data.totalDurationMs
        )
        projectDao.saveFullProject(
            project = updatedProject,
            mediaList = data.mediaList,
            clips = data.clips,
            textClips = data.textClips,
            audioClips = data.audioClips,
            transitions = data.transitions
        )
    }

    suspend fun renameProject(projectId: String, newName: String) = withContext(Dispatchers.IO) {
        val existing = projectDao.getProjectById(projectId) ?: return@withContext
        projectDao.updateProject(existing.copy(name = newName, updatedAt = System.currentTimeMillis()))
    }

    suspend fun duplicateProject(projectId: String): String = withContext(Dispatchers.IO) {
        val full = loadFullProject(projectId) ?: return@withContext ""
        val newProjectId = UUID.randomUUID().toString()
        val mediaIdMap = mutableMapOf<String, String>()

        val newMedia = full.mediaList.map { m ->
            val newId = UUID.randomUUID().toString()
            mediaIdMap[m.id] = newId
            m.copy(id = newId, projectId = newProjectId)
        }

        val newClips = full.clips.map { c ->
            c.copy(
                id = UUID.randomUUID().toString(),
                projectId = newProjectId,
                mediaId = mediaIdMap[c.mediaId] ?: c.mediaId
            )
        }

        val newText = full.textClips.map { t ->
            t.copy(id = UUID.randomUUID().toString(), projectId = newProjectId)
        }

        val newAudio = full.audioClips.map { a ->
            a.copy(id = UUID.randomUUID().toString(), projectId = newProjectId)
        }

        val newMarkers = full.markers.map { m ->
            m.copy(id = UUID.randomUUID().toString(), projectId = newProjectId)
        }

        val newSubtitles = full.subtitles.map { s ->
            s.copy(id = UUID.randomUUID().toString(), projectId = newProjectId)
        }

        val newProject = full.project.copy(
            id = newProjectId,
            name = "${full.project.name} (Salinan)",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        projectDao.saveFullProject(
            project = newProject,
            mediaList = newMedia,
            clips = newClips,
            textClips = newText,
            audioClips = newAudio,
            transitions = emptyList(),
            markers = newMarkers,
            subtitles = newSubtitles
        )
        newProjectId
    }

    suspend fun deleteProject(projectId: String) = withContext(Dispatchers.IO) {
        projectDao.deleteProjectById(projectId)
    }

    // --- Export Project as .zvlproject ZIP ---
    suspend fun exportProjectPackage(projectId: String): File? = withContext(Dispatchers.IO) {
        val full = loadFullProject(projectId) ?: return@withContext null
        val exportDir = File(context.cacheDir, "project_exports").apply { mkdirs() }
        val zipFile = File(exportDir, "${full.project.name.replace(" ", "_")}_$projectId.zvlproject")

        val rootJson = JSONObject().apply {
            put("version", 1)
            put("id", full.project.id)
            put("name", full.project.name)
            put("canvasWidth", full.project.canvasWidth)
            put("canvasHeight", full.project.canvasHeight)
            put("canvasRatio", full.project.canvasRatio)
            put("totalDurationMs", full.totalDurationMs)

            val mediaArr = JSONArray()
            full.mediaList.forEach { m ->
                mediaArr.put(JSONObject().apply {
                    put("id", m.id)
                    put("uri", m.uri)
                    put("type", m.type)
                    put("durationMs", m.durationMs)
                    put("width", m.width)
                    put("height", m.height)
                })
            }
            put("media", mediaArr)

            val clipsArr = JSONArray()
            full.clips.forEach { c ->
                clipsArr.put(JSONObject().apply {
                    put("id", c.id)
                    put("mediaId", c.mediaId)
                    put("orderIndex", c.orderIndex)
                    put("startTimeMs", c.startTimeMs)
                    put("durationMs", c.durationMs)
                    put("sourceStartMs", c.sourceStartMs)
                    put("sourceEndMs", c.sourceEndMs)
                    put("speed", c.speed)
                    put("volume", c.volume)
                    put("filterName", c.filterName)
                })
            }
            put("clips", clipsArr)

            val textArr = JSONArray()
            full.textClips.forEach { t ->
                textArr.put(JSONObject().apply {
                    put("id", t.id)
                    put("text", t.text)
                    put("startTimeMs", t.startTimeMs)
                    put("durationMs", t.durationMs)
                    put("font", t.font)
                    put("colorHex", t.colorHex)
                })
            }
            put("textClips", textArr)
        }

        try {
            ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                val entry = ZipEntry("project.json")
                zos.putNextEntry(entry)
                zos.write(rootJson.toString(2).toByteArray())
                zos.closeEntry()
            }
            zipFile
        } catch (e: Exception) {
            null
        }
    }

    // --- Import .zvlproject with Zip Slip vulnerability protection ---
    suspend fun importProjectPackage(uri: Uri): String? = withContext(Dispatchers.IO) {
        val tempDir = File(context.cacheDir, "import_${UUID.randomUUID()}").apply { mkdirs() }
        var projectJsonString: String? = null

        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                ZipInputStream(stream).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val newFile = File(tempDir, entry.name)
                        // Path traversal check (Zip Slip defense)
                        if (!newFile.canonicalPath.startsWith(tempDir.canonicalPath + File.separator)) {
                            throw SecurityException("Zip Slip detected: ${entry.name}")
                        }
                        if (entry.name == "project.json") {
                            projectJsonString = zis.bufferedReader().readText()
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }

            if (projectJsonString == null) return@withContext null
            val obj = JSONObject(projectJsonString!!)
            val newId = UUID.randomUUID().toString()
            val name = obj.optString("name", "Imported Project") + " (Import)"
            val cWidth = obj.optInt("canvasWidth", 1080)
            val cHeight = obj.optInt("canvasHeight", 1920)
            val cRatio = obj.optString("canvasRatio", "9:16")

            val projectEntity = ProjectEntity(
                id = newId,
                name = name,
                canvasWidth = cWidth,
                canvasHeight = cHeight,
                canvasRatio = cRatio
            )

            val mediaList = mutableListOf<MediaEntity>()
            val mediaIdMap = mutableMapOf<String, String>()
            val mediaArr = obj.optJSONArray("media")
            if (mediaArr != null) {
                for (i in 0 until mediaArr.length()) {
                    val mObj = mediaArr.getJSONObject(i)
                    val oldId = mObj.getString("id")
                    val mNewId = UUID.randomUUID().toString()
                    mediaIdMap[oldId] = mNewId
                    mediaList.add(
                        MediaEntity(
                            id = mNewId,
                            projectId = newId,
                            uri = mObj.optString("uri", ""),
                            type = mObj.optString("type", "video"),
                            durationMs = mObj.optLong("durationMs", 5000L),
                            width = mObj.optInt("width", 1080),
                            height = mObj.optInt("height", 1920)
                        )
                    )
                }
            }

            val clipsList = mutableListOf<ClipEntity>()
            val clipsArr = obj.optJSONArray("clips")
            if (clipsArr != null) {
                for (i in 0 until clipsArr.length()) {
                    val cObj = clipsArr.getJSONObject(i)
                    val oldMediaId = cObj.optString("mediaId", "")
                    clipsList.add(
                        ClipEntity(
                            id = UUID.randomUUID().toString(),
                            projectId = newId,
                            mediaId = mediaIdMap[oldMediaId] ?: oldMediaId,
                            orderIndex = cObj.optInt("orderIndex", i),
                            startTimeMs = cObj.optLong("startTimeMs", 0L),
                            durationMs = cObj.optLong("durationMs", 5000L),
                            sourceStartMs = cObj.optLong("sourceStartMs", 0L),
                            sourceEndMs = cObj.optLong("sourceEndMs", 5000L),
                            speed = cObj.optDouble("speed", 1.0).toFloat(),
                            volume = cObj.optDouble("volume", 1.0).toFloat(),
                            filterName = cObj.optString("filterName", "ORIGINAL")
                        )
                    )
                }
            }

            projectDao.saveFullProject(projectEntity, mediaList, clipsList, emptyList(), emptyList(), emptyList())
            newId
        } catch (e: Exception) {
            null
        } finally {
            tempDir.deleteRecursively()
        }
    }
}
