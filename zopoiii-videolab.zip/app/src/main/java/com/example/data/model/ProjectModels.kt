package com.example.data.model

import com.example.data.database.entities.AudioClipEntity
import com.example.data.database.entities.ClipEntity
import com.example.data.database.entities.MarkerEntity
import com.example.data.database.entities.MediaEntity
import com.example.data.database.entities.ProjectEntity
import com.example.data.database.entities.ShapeEntity
import com.example.data.database.entities.StickerEntity
import com.example.data.database.entities.SubtitleEntity
import com.example.data.database.entities.TextClipEntity
import com.example.data.database.entities.TransitionEntity

data class FullProjectData(
    val project: ProjectEntity,
    val mediaList: List<MediaEntity>,
    val clips: List<ClipEntity>,
    val textClips: List<TextClipEntity> = emptyList(),
    val audioClips: List<AudioClipEntity> = emptyList(),
    val transitions: List<TransitionEntity> = emptyList(),
    val markers: List<MarkerEntity> = emptyList(),
    val subtitles: List<SubtitleEntity> = emptyList(),
    val stickers: List<StickerEntity> = emptyList(),
    val shapes: List<ShapeEntity> = emptyList()
) {
    val totalDurationMs: Long
        get() = maxOf(
            clips.maxOfOrNull { it.startTimeMs + it.durationMs } ?: 0L,
            audioClips.maxOfOrNull { it.startTimeMs + it.durationMs } ?: 0L,
            textClips.maxOfOrNull { it.startTimeMs + it.durationMs } ?: 0L,
            subtitles.maxOfOrNull { it.endMs } ?: 0L
        )
}

data class EditableClip(
    val clip: ClipEntity,
    val media: MediaEntity?
)
