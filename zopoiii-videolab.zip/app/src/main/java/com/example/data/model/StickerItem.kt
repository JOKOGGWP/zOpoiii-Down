package com.example.data.model

data class StickerItem(
    val id: String,
    val emojiOrIcon: String,
    val name: String,
    val positionX: Float = 0.5f,
    val positionY: Float = 0.5f,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f,
    val startTimeMs: Long = 0L,
    val durationMs: Long = 3000L
) {
    companion object {
        val sampleStickers = listOf(
            "🔥" to "Fire",
            "✨" to "Sparkle",
            "🎬" to "Action",
            "⭐" to "Star",
            "❤️" to "Heart",
            "⚡" to "Lightning",
            "🎉" to "Party",
            "💯" to "100",
            "👀" to "Look",
            "🚀" to "Rocket",
            "💥" to "Boom",
            "👍" to "Thumbs Up"
        )
    }
}
