package com.example.data.model

data class ExportSettings(
    val resolutionMode: String = "CANVAS", // "CANVAS", "ORIGINAL", "CUSTOM", "PRESET"
    val customWidth: Int = 1080,
    val customHeight: Int = 1920,
    val fps: Int = 30,
    val bitrateMode: String = "AUTO", // "AUTO", "CUSTOM"
    val customBitrateMbps: Int = 8,
    val videoCodec: String = "H264", // "H264", "HEVC"
    val audioCodec: String = "AAC", // "AAC", "OPUS"
    val audioSampleRate: Int = 44100, // 44100, 48000, 96000
    val audioBitrateKbps: Int = 192, // 64, 96, 128, 160, 192, 256, 320
    val audioChannels: Int = 2, // 1 (Mono), 2 (Stereo)
    val colorFormat: String = "SDR", // "SDR", "HDR"
    val includeMetadata: Boolean = true,
    val customFileName: String = ""
) {
    fun calculateTargetDimensions(canvasWidth: Int, canvasHeight: Int): Pair<Int, Int> {
        return when (resolutionMode) {
            "CANVAS" -> canvasWidth to canvasHeight
            "CUSTOM" -> customWidth.coerceIn(16, 8192) to customHeight.coerceIn(16, 8192)
            else -> customWidth to customHeight
        }
    }

    fun calculateTargetBitrateBps(targetWidth: Int, targetHeight: Int, targetFps: Int): Int {
        if (bitrateMode == "CUSTOM" && customBitrateMbps > 0) {
            return customBitrateMbps * 1_000_000
        }
        // Auto bitrate calculation based on resolution & FPS
        val pixels = targetWidth.toLong() * targetHeight
        val baseBps = when {
            pixels >= 3840 * 2160 -> 35_000_000 // 4K
            pixels >= 2560 * 1440 -> 18_000_000 // 2K
            pixels >= 1920 * 1080 -> 10_000_000 // 1080p
            pixels >= 1280 * 720 -> 5_000_000   // 720p
            else -> 2_500_000                   // 480p/SD
        }
        val fpsFactor = (targetFps / 30f).coerceIn(0.7f, 2.0f)
        return (baseBps * fpsFactor).toInt()
    }
}

enum class ExportResolution(val label: String, val width: Int, val height: Int, val isHighEnd: Boolean) {
    RES_480P("480p (SD)", 854, 480, false),
    RES_720P("720p (HD)", 1280, 720, false),
    RES_1080P("1080p (FHD)", 1920, 1080, false),
    RES_1440P("1440p (2K)", 2560, 1440, true),
    RES_4K("2160p (4K UHD)", 3840, 2160, true);

    companion object {
        fun fromLabel(label: String): ExportResolution {
            return entries.firstOrNull { it.label.startsWith(label) || it.name == label } ?: RES_1080P
        }
    }
}

enum class ExportFps(val label: String, val fpsValue: Int) {
    FPS_15("15 fps", 15),
    FPS_24("24 fps (Cinematic)", 24),
    FPS_25("25 fps (PAL)", 25),
    FPS_30("30 fps (Standard)", 30),
    FPS_50("50 fps", 50),
    FPS_60("60 fps (Smooth)", 60),
    FPS_120("120 fps (High)", 120)
}

enum class ExportBitrate(val label: String, val bpsMultiplier: Float) {
    AUTO("Auto (Optimal)", 1.0f),
    LOW("Space Saver (1 Mbps)", 0.5f),
    MEDIUM("Standard (8 Mbps)", 1.0f),
    HIGH("High Quality (16 Mbps)", 1.6f),
    ULTRA("Ultra (30 Mbps)", 3.0f)
}

enum class ExportCodec(val label: String, val mimeType: String) {
    H264("H.264 / AVC (Widely Compatible)", "video/avc"),
    HEVC("H.265 / HEVC (High Compression)", "video/hevc")
}
