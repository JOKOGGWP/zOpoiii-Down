package com.example.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_settings")

data class UserPreferences(
    val themeMode: String = "DARK", // "DARK", "LIGHT", "SYSTEM"
    val language: String = "id",
    val defaultResolution: String = "1080p (FHD)",
    val defaultFps: Int = 30,
    val defaultBitrate: String = "AUTO",
    val autosaveEnabled: Boolean = true,
    val hardwareAcceleration: Boolean = true
)

class UserPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val DEFAULT_RESOLUTION = stringPreferencesKey("default_resolution")
        val DEFAULT_FPS = stringPreferencesKey("default_fps")
        val DEFAULT_BITRATE = stringPreferencesKey("default_bitrate")
        val AUTOSAVE_ENABLED = booleanPreferencesKey("autosave_enabled")
        val HARDWARE_ACCELERATION = booleanPreferencesKey("hardware_acceleration")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            themeMode = prefs[PreferencesKeys.THEME_MODE] ?: "DARK",
            language = prefs[PreferencesKeys.LANGUAGE] ?: "id",
            defaultResolution = prefs[PreferencesKeys.DEFAULT_RESOLUTION] ?: "1080p (FHD)",
            defaultFps = prefs[PreferencesKeys.DEFAULT_FPS]?.toIntOrNull() ?: 30,
            defaultBitrate = prefs[PreferencesKeys.DEFAULT_BITRATE] ?: "AUTO",
            autosaveEnabled = prefs[PreferencesKeys.AUTOSAVE_ENABLED] ?: true,
            hardwareAcceleration = prefs[PreferencesKeys.HARDWARE_ACCELERATION] ?: true
        )
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.THEME_MODE] = mode
        }
    }

    suspend fun setDefaultResolution(res: String) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.DEFAULT_RESOLUTION] = res
        }
    }

    suspend fun setHardwareAcceleration(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.HARDWARE_ACCELERATION] = enabled
        }
    }

    suspend fun setAutosaveEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.AUTOSAVE_ENABLED] = enabled
        }
    }
}
