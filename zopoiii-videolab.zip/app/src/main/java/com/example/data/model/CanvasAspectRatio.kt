package com.example.data.model

enum class CanvasAspectRatio(val label: String, val ratioWidth: Float, val ratioHeight: Float, val defaultWidth: Int, val defaultHeight: Int) {
    RATIO_9_16("9:16", 9f, 16f, 1080, 1920),
    RATIO_16_9("16:9", 16f, 9f, 1920, 1080),
    RATIO_1_1("1:1", 1f, 1f, 1080, 1080),
    RATIO_4_3("4:3", 4f, 3f, 1440, 1080),
    RATIO_3_4("3:4", 3f, 4f, 1080, 1440),
    RATIO_21_9("21:9", 21f, 9f, 2560, 1080),
    RATIO_9_21("9:21", 9f, 21f, 1080, 2520),
    RATIO_2_1("2:1", 2f, 1f, 2160, 1080),
    RATIO_1_2("1:2", 1f, 2f, 1080, 2160),
    CUSTOM("Custom", 1f, 1f, 1080, 1920);

    val aspectRatio: Float
        get() = ratioWidth / ratioHeight

    companion object {
        fun fromLabel(label: String): CanvasAspectRatio {
            return entries.firstOrNull { it.label.equals(label, ignoreCase = true) } ?: RATIO_9_16
        }
    }
}
