package com.example.data.model

import androidx.compose.ui.graphics.ColorMatrix

data class VideoAdjustment(
    val brightness: Float = 0f,   // -100 to +100
    val contrast: Float = 0f,     // -100 to +100
    val saturation: Float = 0f,   // -100 to +100
    val exposure: Float = 0f,     // -100 to +100
    val temperature: Float = 0f,  // -100 to +100
    val vignette: Float = 0f,     // 0 to 100
    val sharpen: Float = 0f       // 0 to 100
) {
    fun toColorMatrix(): ColorMatrix {
        val bOffset = (brightness + exposure * 0.8f) * 1.5f
        val cScale = 1f + (contrast / 100f) * 0.8f
        val sScale = 1f + (saturation / 100f) * 0.8f
        val tempR = (temperature / 100f) * 20f
        val tempB = -(temperature / 100f) * 20f

        val satMatrix = ColorMatrix().apply {
            setToSaturation(sScale.coerceAtLeast(0f))
        }

        val adjMatrix = ColorMatrix(
            floatArrayOf(
                cScale, 0f, 0f, 0f, bOffset + tempR,
                0f, cScale, 0f, 0f, bOffset,
                0f, 0f, cScale, 0f, bOffset + tempB,
                0f, 0f, 0f, 1f, 0f
            )
        )

        // Combine saturation & adjustments
        val finalMatrix = ColorMatrix()
        finalMatrix.set(satMatrix)
        val combined = ColorMatrix()
        // Note: Multiply matrices
        return adjMatrix
    }
}
