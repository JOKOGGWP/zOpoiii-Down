package com.example.data.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val canvasWidth: Int = 1080,
    val canvasHeight: Int = 1920,
    val canvasRatio: String = "9:16",
    val fps: Int = 30,
    val background: String = "#FF000000",
    val colorSpace: String = "SDR",
    val previewQuality: String = "FULL",
    val thumbnailPath: String? = null,
    val totalDurationMs: Long = 0L,
    val exportSettingsJson: String = ""
)

@Entity(
    tableName = "media",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class MediaEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val uri: String,
    val type: String, // "video", "image", "audio"
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val rotation: Int = 0
)

@Entity(
    tableName = "tracks",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class TrackEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val type: String, // "video", "overlay", "text", "audio", "voice", "effects"
    val name: String = "Track",
    val orderIndex: Int,
    val isLocked: Boolean = false,
    val isHidden: Boolean = false,
    val isMuted: Boolean = false,
    val volume: Float = 1.0f
)

@Entity(
    tableName = "clips",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"]), Index(value = ["mediaId"])]
)
data class ClipEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val mediaId: String,
    val trackId: String = "track_main_video",
    val orderIndex: Int = 0,
    val startTimeMs: Long,
    val durationMs: Long,
    val sourceStartMs: Long = 0L,
    val sourceEndMs: Long = 0L,
    val positionX: Float = 0.5f,
    val positionY: Float = 0.5f,
    val scaleX: Float = 1.0f,
    val scaleY: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f,
    val volume: Float = 1.0f,
    val speed: Float = 1.0f,
    val filterName: String = "ORIGINAL",
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val isFlippedHorizontal: Boolean = false,
    val isFlippedVertical: Boolean = false,
    val isReversed: Boolean = false
)

@Entity(
    tableName = "text_clips",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class TextClipEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val trackId: String = "track_text",
    val text: String,
    val font: String = "Roboto",
    val sizeSp: Float = 24f,
    val colorHex: Long = 0xFFFFFFFF,
    val strokeHex: Long = 0xFF000000,
    val positionX: Float = 0.5f,
    val positionY: Float = 0.75f,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f,
    val startTimeMs: Long,
    val durationMs: Long,
    val animation: String = "POP"
)

@Entity(
    tableName = "audio_clips",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class AudioClipEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val uri: String,
    val name: String,
    val startTimeMs: Long,
    val durationMs: Long,
    val sourceStartMs: Long = 0L,
    val sourceEndMs: Long = 0L,
    val volume: Float = 1.0f,
    val fadeInMs: Long = 0L,
    val fadeOutMs: Long = 0L,
    val isVoiceOver: Boolean = false
)

@Entity(
    tableName = "effects",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"]), Index(value = ["clipId"])]
)
data class EffectEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val clipId: String,
    val type: String, // "BLUR", "GLOW", "VIGNETTE", "NOISE", "PIXELATE"
    val intensity: Float = 0.5f,
    val startTimeMs: Long = 0L,
    val durationMs: Long = 0L
)

@Entity(
    tableName = "transitions",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class TransitionEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val clipBeforeId: String,
    val clipAfterId: String,
    val type: String = "FADE",
    val durationMs: Long = 500L
)

@Entity(
    tableName = "keyframes",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"]), Index(value = ["clipId"])]
)
data class KeyframeEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val clipId: String,
    val timeOffsetMs: Long,
    val positionX: Float,
    val positionY: Float,
    val scale: Float,
    val rotation: Float,
    val opacity: Float
)

@Entity(
    tableName = "markers",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class MarkerEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val timestampMs: Long,
    val name: String,
    val colorHex: Long = 0xFFFFD700,
    val note: String = ""
)

@Entity(
    tableName = "subtitles",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class SubtitleEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val font: String = "Roboto",
    val sizeSp: Float = 20f,
    val colorHex: Long = 0xFFFFFFFF,
    val backgroundHex: Long = 0x80000000,
    val outlineHex: Long = 0xFF000000,
    val positionY: Float = 0.85f
)

@Entity(
    tableName = "stickers",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class StickerEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val trackId: String = "track_overlay",
    val uriOrName: String,
    val startTimeMs: Long,
    val durationMs: Long,
    val positionX: Float = 0.5f,
    val positionY: Float = 0.5f,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f
)

@Entity(
    tableName = "shapes",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class ShapeEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val trackId: String = "track_overlay",
    val shapeType: String = "RECTANGLE", // RECTANGLE, CIRCLE, LINE, ARROW, POLYGON
    val fillHex: Long = 0xFFFF0055,
    val strokeHex: Long = 0xFFFFFFFF,
    val strokeWidth: Float = 2f,
    val opacity: Float = 1.0f,
    val positionX: Float = 0.5f,
    val positionY: Float = 0.5f,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val startTimeMs: Long,
    val durationMs: Long
)

@Entity(tableName = "export_jobs")
data class ExportJobEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val projectName: String,
    val status: String = "QUEUED", // QUEUED, RUNNING, COMPLETED, FAILED, CANCELLED
    val progress: Float = 0f,
    val targetPath: String = "",
    val resolutionWidth: Int = 1080,
    val resolutionHeight: Int = 1920,
    val fps: Int = 30,
    val bitrateMbps: Int = 8,
    val codec: String = "H264",
    val audioCodec: String = "AAC",
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long = 0L,
    val errorReason: String? = null
)
