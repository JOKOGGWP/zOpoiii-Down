package com.example.editor.undo

import com.example.data.database.entities.AudioClipEntity
import com.example.data.database.entities.ClipEntity
import com.example.data.database.entities.TextClipEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Stack

sealed interface EditorCommand {
    data class SplitClip(
        val originalClip: ClipEntity,
        val partA: ClipEntity,
        val partB: ClipEntity
    ) : EditorCommand

    data class DeleteClip(
        val deletedClip: ClipEntity,
        val originalIndex: Int
    ) : EditorCommand

    data class AddClip(
        val clip: ClipEntity
    ) : EditorCommand

    data class TrimClip(
        val clipId: String,
        val oldSourceStart: Long,
        val oldSourceEnd: Long,
        val oldDuration: Long,
        val newSourceStart: Long,
        val newSourceEnd: Long,
        val newDuration: Long
    ) : EditorCommand

    data class ChangeSpeed(
        val clipId: String,
        val oldSpeed: Float,
        val oldDuration: Long,
        val newSpeed: Float,
        val newDuration: Long
    ) : EditorCommand

    data class ChangeFilter(
        val clipId: String,
        val oldFilter: String,
        val newFilter: String
    ) : EditorCommand

    data class ChangeAdjustment(
        val clipId: String,
        val oldB: Float,
        val oldC: Float,
        val oldS: Float,
        val newB: Float,
        val newC: Float,
        val newS: Float
    ) : EditorCommand

    data class AddText(
        val textClip: TextClipEntity
    ) : EditorCommand

    data class DeleteText(
        val textClip: TextClipEntity
    ) : EditorCommand

    data class AddAudio(
        val audioClip: AudioClipEntity
    ) : EditorCommand

    data class DeleteAudio(
        val audioClip: AudioClipEntity
    ) : EditorCommand
}

class UndoRedoManager {
    private val undoStack = Stack<EditorCommand>()
    private val redoStack = Stack<EditorCommand>()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    fun push(command: EditorCommand) {
        undoStack.push(command)
        redoStack.clear()
        updateState()
    }

    fun popUndo(): EditorCommand? {
        if (undoStack.isEmpty()) return null
        val cmd = undoStack.pop()
        redoStack.push(cmd)
        updateState()
        return cmd
    }

    fun popRedo(): EditorCommand? {
        if (redoStack.isEmpty()) return null
        val cmd = redoStack.pop()
        undoStack.push(cmd)
        updateState()
        return cmd
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
        updateState()
    }

    private fun updateState() {
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }
}
