package com.example.ui.editor.components

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.database.entities.ClipEntity
import com.example.data.database.entities.ShapeEntity
import com.example.data.database.entities.StickerEntity
import com.example.data.database.entities.SubtitleEntity
import com.example.data.database.entities.TextClipEntity
import com.example.data.model.CanvasAspectRatio
import com.example.media.TimelinePlayerManager
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.ElectricCyan
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
@Composable
fun VideoPreviewCanvas(
    playerManager: TimelinePlayerManager,
    canvasRatio: CanvasAspectRatio,
    activeClip: ClipEntity?,
    textClips: List<TextClipEntity>,
    subtitles: List<SubtitleEntity> = emptyList(),
    stickers: List<StickerEntity> = emptyList(),
    shapes: List<ShapeEntity> = emptyList(),
    playheadMs: Long,
    modifier: Modifier = Modifier,
    onTogglePlayPause: () -> Unit = {}
) {
    val isPlaying by playerManager.isPlaying.collectAsState()

    // Aspect ratio of the canvas
    val targetRatio = canvasRatio.aspectRatio

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Black)
            .testTag("video_preview_canvas"),
        contentAlignment = Alignment.Center
    ) {
        // Framed Canvas Container
        Box(
            modifier = Modifier
                .padding(8.dp)
                .aspectRatio(targetRatio, matchHeightConstraintsFirst = false)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.Black)
                .border(1.dp, DarkOutline.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .clickable { onTogglePlayPause() },
            contentAlignment = Alignment.Center
        ) {
            // Media3 PlayerView
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = playerManager.player
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .then(
                        if (activeClip != null) {
                            Modifier
                                .scale(
                                    scaleX = if (activeClip.isFlippedHorizontal) -1f else 1f,
                                    scaleY = if (activeClip.isFlippedVertical) -1f else 1f
                                )
                                .rotate(activeClip.rotation)
                        } else Modifier
                    )
            )

            // Shapes Overlays active at current playhead
            shapes.filter {
                playheadMs >= it.startTimeMs && playheadMs < (it.startTimeMs + it.durationMs)
            }.forEach { shape ->
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset {
                            IntOffset(
                                x = ((shape.positionX - 0.5f) * 350).roundToInt(),
                                y = ((shape.positionY - 0.5f) * 550).roundToInt()
                            )
                        }
                        .rotate(shape.rotation)
                        .scale(shape.scale)
                        .size(60.dp)
                        .background(Color(shape.fillHex), shape = when (shape.shapeType.lowercase()) {
                            "lingkaran", "circle" -> CircleShape
                            else -> RoundedCornerShape(8.dp)
                        })
                )
            }

            // Text Overlays active at current playhead
            textClips.filter {
                playheadMs >= it.startTimeMs && playheadMs < (it.startTimeMs + it.durationMs)
            }.forEach { textClip ->
                val font = when (textClip.font.lowercase()) {
                    "serif" -> FontFamily.Serif
                    "monospace" -> FontFamily.Monospace
                    "sans" -> FontFamily.SansSerif
                    else -> FontFamily.Default
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset {
                            // Relative position (-0.5 to +0.5)
                            IntOffset(
                                x = ((textClip.positionX - 0.5f) * 400).roundToInt(),
                                y = ((textClip.positionY - 0.5f) * 600).roundToInt()
                            )
                        }
                        .rotate(textClip.rotation)
                        .scale(textClip.scale)
                        .alpha(textClip.opacity)
                        .background(
                            color = Color(0x66000000),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = textClip.text,
                        fontSize = textClip.sizeSp.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = font,
                        color = Color(textClip.colorHex.toInt())
                    )
                }
            }

            // Subtitles active at current playhead (Bottom Center)
            subtitles.firstOrNull {
                playheadMs >= it.startMs && playheadMs <= it.endMs
            }?.let { sub ->
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp)
                        .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = sub.text,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // Play icon overlay when paused
            AnimatedVisibility(
                visible = !isPlaying,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                        .border(1.5.dp, ElectricCyan.copy(alpha = 0.8f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = ElectricCyan,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}
