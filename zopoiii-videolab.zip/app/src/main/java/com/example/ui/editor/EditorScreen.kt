package com.example.ui.editor

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.entities.AudioClipEntity
import com.example.data.model.CanvasAspectRatio
import com.example.media.MediaUtils
import com.example.ui.editor.components.AdjustPanel
import com.example.ui.editor.components.AudioPanel
import com.example.ui.editor.components.CanvasRatioPanel
import com.example.ui.editor.components.ClipActionsRow
import com.example.ui.editor.components.ExportSheet
import com.example.ui.editor.components.FilterPanel
import com.example.ui.editor.components.MarkerPanel
import com.example.ui.editor.components.PrimaryEditorToolTabs
import com.example.ui.editor.components.ShapePanel
import com.example.ui.editor.components.SpeedPanel
import com.example.ui.editor.components.StickerPanel
import com.example.ui.editor.components.SubtitlePanel
import com.example.ui.editor.components.TextAddPanel
import com.example.ui.editor.components.TimelineTrackView
import com.example.ui.editor.components.TransitionPanel
import com.example.ui.editor.components.VideoPreviewCanvas
import com.example.ui.editor.components.VolumePanel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val project by viewModel.project.collectAsState()
    val clips by viewModel.clips.collectAsState()
    val mediaMap by viewModel.mediaMap.collectAsState()
    val textClips by viewModel.textClips.collectAsState()
    val audioClips by viewModel.audioClips.collectAsState()
    val transitions by viewModel.transitions.collectAsState()
    val markers by viewModel.markers.collectAsState()
    val subtitles by viewModel.subtitles.collectAsState()
    val stickers by viewModel.stickers.collectAsState()
    val shapes by viewModel.shapes.collectAsState()
    val isRippleMode by viewModel.isRippleMode.collectAsState()
    val isSnapEnabled by viewModel.isSnapEnabled.collectAsState()
    val selectedClipId by viewModel.selectedClipId.collectAsState()
    val activeToolTab by viewModel.activeToolTab.collectAsState()

    val playheadMs by viewModel.playheadMs.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val canUndo by viewModel.canUndo.collectAsState()
    val canRedo by viewModel.canRedo.collectAsState()

    var showExportSheet by remember { mutableStateOf(false) }
    var showJumpToTimeDialog by remember { mutableStateOf(false) }
    var jumpTimeText by remember { mutableStateOf("") }
    var transitionTargetClips by remember { mutableStateOf<Pair<String, String>?>(null) }

    // Media Picker for adding clips
    val addMediaLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 20)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.addMediaFiles(uris)
        }
    }

    // Audio Picker for background music
    val addAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val audioEntity = AudioClipEntity(
                id = java.util.UUID.randomUUID().toString(),
                projectId = project?.id ?: "",
                uri = uri.toString(),
                name = "Musik Latar",
                startTimeMs = playheadMs,
                durationMs = 15000L,
                volume = 1.0f
            )
            // Push audio
            viewModel.addRecordedVoiceOver(
                audioFile = java.io.File(uri.path ?: ""),
                durationMs = 15000L
            )
        }
    }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is EditorUiEvent.ShowToast -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
                is EditorUiEvent.OpenMediaPicker -> {
                    addMediaLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                    )
                }
                is EditorUiEvent.OpenAudioPicker -> {
                    addAudioLauncher.launch("audio/*")
                }
                is EditorUiEvent.OpenCameraRecord -> {}
            }
        }
    }

    val selectedClip = clips.firstOrNull { it.id == selectedClipId }
    val totalDurationMs = clips.maxOfOrNull { it.startTimeMs + it.durationMs } ?: 0L
    val activeCanvasRatio = CanvasAspectRatio.fromLabel(project?.canvasRatio ?: "9:16")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = project?.name ?: "Video Editor",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = DarkSurfaceElevated,
                                modifier = Modifier.clickable { viewModel.setToolTab(EditorToolTab.CANVAS) }
                            ) {
                                Text(
                                    text = activeCanvasRatio.label,
                                    fontSize = 10.sp,
                                    color = ElectricCyan,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Kembali",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    // Undo
                    IconButton(
                        onClick = { viewModel.undo() },
                        enabled = canUndo,
                        modifier = Modifier.testTag("undo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo",
                            tint = if (canUndo) TextPrimary else TextTertiary
                        )
                    }

                    // Redo
                    IconButton(
                        onClick = { viewModel.redo() },
                        enabled = canRedo,
                        modifier = Modifier.testTag("redo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo",
                            tint = if (canRedo) TextPrimary else TextTertiary
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Export Button
                    Button(
                        onClick = { showExportSheet = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("export_button")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ekspor", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // --- 1. Video Canvas Preview ---
            VideoPreviewCanvas(
                playerManager = viewModel.playerManager,
                canvasRatio = activeCanvasRatio,
                activeClip = selectedClip,
                textClips = textClips,
                subtitles = subtitles,
                stickers = stickers,
                shapes = shapes,
                playheadMs = playheadMs,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                onTogglePlayPause = { viewModel.playerManager.togglePlayPause() }
            )

            // --- 2. Playhead & Playback Controls Bar ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Timecode with Jump dialog trigger
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = DarkSurfaceElevated,
                    modifier = Modifier.clickable {
                        jumpTimeText = MediaUtils.formatTime(playheadMs)
                        showJumpToTimeDialog = true
                    }
                ) {
                    Text(
                        text = "${MediaUtils.formatTime(playheadMs)} / ${MediaUtils.formatTime(totalDurationMs)}",
                        fontSize = 11.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        color = ElectricCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                // Snap & Ripple Toggle Badges
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isSnapEnabled) ElectricCyan.copy(alpha = 0.2f) else DarkSurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSnapEnabled) ElectricCyan else DarkOutline),
                        modifier = Modifier.clickable { viewModel.toggleSnap() }
                    ) {
                        Text(
                            text = "SNAP",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSnapEnabled) ElectricCyan else TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isRippleMode) NeonViolet.copy(alpha = 0.2f) else DarkSurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isRippleMode) NeonViolet else DarkOutline),
                        modifier = Modifier.clickable { viewModel.toggleRippleMode() }
                    ) {
                        Text(
                            text = "RIPPLE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isRippleMode) NeonViolet else TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }

                // Quick Split Button
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = DarkSurfaceElevated,
                    modifier = Modifier.clickable { viewModel.splitClipAtPlayhead() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ContentCut, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Bagi", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                }

                // Frame Stepping & Play / Pause
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Step Back 1 Frame
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = DarkSurfaceElevated,
                        modifier = Modifier
                            .clickable { viewModel.stepFrame(-1) }
                            .padding(end = 4.dp)
                    ) {
                        Text(
                            "-1Fr",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            val prev = clips.lastOrNull { it.startTimeMs < playheadMs - 100L }
                            viewModel.playerManager.seekTo(prev?.startTimeMs ?: 0L)
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.SkipPrevious, contentDescription = "Sebelumnya", tint = TextSecondary, modifier = Modifier.size(20.dp))
                    }

                    IconButton(
                        onClick = { viewModel.playerManager.togglePlayPause() },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Jeda" else "Putar",
                            tint = ElectricCyan,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            val next = clips.firstOrNull { it.startTimeMs > playheadMs + 100L }
                            viewModel.playerManager.seekTo(next?.startTimeMs ?: totalDurationMs)
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.SkipNext, contentDescription = "Berikutnya", tint = TextSecondary, modifier = Modifier.size(20.dp))
                    }

                    // Step Forward 1 Frame
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = DarkSurfaceElevated,
                        modifier = Modifier
                            .clickable { viewModel.stepFrame(1) }
                            .padding(start = 4.dp)
                    ) {
                        Text(
                            "+1Fr",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // --- 3. Multi-Track Timeline ---
            TimelineTrackView(
                clips = clips,
                mediaMap = mediaMap,
                textClips = textClips,
                audioClips = audioClips,
                transitions = transitions,
                markers = markers,
                subtitles = subtitles,
                selectedClipId = selectedClipId,
                playheadMs = playheadMs,
                isPlaying = isPlaying,
                onSeek = { viewModel.playerManager.seekTo(it) },
                onSelectClip = { viewModel.selectClip(it) },
                onTrimClip = { start, end -> viewModel.trimSelectedClip(start, end) },
                onAddMediaClick = {
                    addMediaLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                    )
                },
                onTransitionClick = { beforeId, afterId ->
                    transitionTargetClips = beforeId to afterId
                    viewModel.setToolTab(EditorToolTab.TRANSITION)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            )

            // --- 4. Sub-Panel (Contextual tools for active tab or selected clip) ---
            AnimatedVisibility(
                visible = activeToolTab != EditorToolTab.NONE,
                enter = slideInVertically { it },
                exit = slideOutVertically { it }
            ) {
                when (activeToolTab) {
                    EditorToolTab.CLIP_TOOLS -> {
                        ClipActionsRow(
                            selectedClip = selectedClip,
                            onSplit = { viewModel.splitClipAtPlayhead() },
                            onDelete = { viewModel.deleteSelectedClip() },
                            onDuplicate = { viewModel.duplicateSelectedClip() },
                            onRotate = { viewModel.rotateSelectedClip() },
                            onFlipH = { viewModel.flipHorizontalSelectedClip() },
                            onExtractAudio = { viewModel.extractAudioFromSelectedClip() },
                            onFreezeFrame = { viewModel.freezeFrameAtPlayhead() },
                            onOpenSpeed = { viewModel.setToolTab(EditorToolTab.SPEED) },
                            onOpenVolume = { viewModel.setToolTab(EditorToolTab.CLIP_TOOLS) }, // Inline toggle or open volume
                            onOpenFilter = { viewModel.setToolTab(EditorToolTab.FILTER) },
                            onOpenAdjust = { viewModel.setToolTab(EditorToolTab.ADJUST) }
                        )
                    }
                    EditorToolTab.SPEED -> {
                        SpeedPanel(
                            currentSpeed = selectedClip?.speed ?: 1.0f,
                            onSpeedChange = { viewModel.setSpeedSelectedClip(it) },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    EditorToolTab.FILTER -> {
                        FilterPanel(
                            activeFilter = selectedClip?.filterName ?: "ORIGINAL",
                            onSelectFilter = { viewModel.setFilterSelectedClip(it) },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    EditorToolTab.ADJUST -> {
                        AdjustPanel(
                            brightness = selectedClip?.brightness ?: 0f,
                            contrast = selectedClip?.contrast ?: 0f,
                            saturation = selectedClip?.saturation ?: 0f,
                            onAdjustChange = { b, c, s -> viewModel.setAdjustmentSelectedClip(b, c, s) },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    EditorToolTab.AUDIO -> {
                        AudioPanel(
                            audioRecorder = viewModel.audioRecorder,
                            onAddAudioFile = { addAudioLauncher.launch("audio/*") },
                            onVoiceOverRecorded = { file, dur -> viewModel.addRecordedVoiceOver(file, dur) },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    EditorToolTab.TEXT -> {
                        TextAddPanel(
                            onAddText = { txt, font, color -> viewModel.addTextClip(txt, font, color) },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    EditorToolTab.SUBTITLE -> {
                        SubtitlePanel(
                            subtitles = subtitles,
                            onAddSubtitle = { viewModel.addSubtitleAtPlayhead(it) },
                            onDeleteSubtitle = { viewModel.deleteSubtitle(it) },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    EditorToolTab.MARKER -> {
                        MarkerPanel(
                            markers = markers,
                            onAddMarker = { name, color -> viewModel.addMarkerAtPlayhead(name, color) },
                            onDeleteMarker = { viewModel.deleteMarker(it) },
                            onJumpToMarker = { viewModel.seekTo(it) },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    EditorToolTab.SHAPE -> {
                        ShapePanel(
                            onAddShape = { type, color -> viewModel.addShape(type, color) },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    EditorToolTab.STICKER -> {
                        StickerPanel(
                            onAddSticker = { emoji ->
                                // Add emoji sticker as a text clip
                                viewModel.addTextClip(emoji, "Roboto", 0xFFFFFFFF)
                            },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    EditorToolTab.CANVAS -> {
                        CanvasRatioPanel(
                            currentRatio = activeCanvasRatio.label,
                            currentWidth = project?.canvasWidth ?: 1080,
                            currentHeight = project?.canvasHeight ?: 1920,
                            onSelectRatio = { viewModel.setCanvasRatio(it) },
                            onApplyCustomSize = { w, h -> viewModel.setCustomCanvasDimensions(w, h, "Custom") },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    EditorToolTab.TRANSITION -> {
                        TransitionPanel(
                            onSelectTransition = { type, dur ->
                                transitionTargetClips?.let { (b, a) ->
                                    viewModel.setTransition(b, a, type, dur)
                                }
                            },
                            onClose = { viewModel.setToolTab(EditorToolTab.NONE) }
                        )
                    }
                    else -> {}
                }
            }

            // --- 5. Primary Tool Tabs ---
            PrimaryEditorToolTabs(
                activeTab = activeToolTab,
                onTabSelected = { viewModel.setToolTab(it) }
            )
        }
    }

    // --- Export Modal BottomSheet ---
    if (showExportSheet) {
        ExportSheet(
            exportEngine = viewModel.exportEngine,
            totalDurationMs = totalDurationMs,
            onStartExport = { settings ->
                viewModel.startExport(settings)
            },
            onDismiss = { showExportSheet = false }
        )
    }

    // --- Jump to Timecode Dialog ---
    if (showJumpToTimeDialog) {
        AlertDialog(
            onDismissRequest = { showJumpToTimeDialog = false },
            title = { Text("Lompat ke Detik", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Masukkan format MM:SS atau detik (misal 01:25 atau 45):", fontSize = 13.sp, color = TextSecondary)
                    OutlinedTextField(
                        value = jumpTimeText,
                        onValueChange = { jumpTimeText = it },
                        singleLine = true,
                        placeholder = { Text("00:00") }
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val parsed = parseTimecodeToMs(jumpTimeText)
                        if (parsed != null) {
                            viewModel.seekTo(parsed.coerceIn(0L, totalDurationMs))
                        }
                        showJumpToTimeDialog = false
                    }
                ) {
                    Text("Lompat", color = ElectricCyan, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showJumpToTimeDialog = false }) {
                    Text("Batal", color = TextSecondary)
                }
            }
        )
    }
}

private fun parseTimecodeToMs(input: String): Long? {
    val clean = input.trim()
    if (clean.contains(":")) {
        val parts = clean.split(":")
        if (parts.size == 2) {
            val min = parts[0].toLongOrNull() ?: return null
            val sec = parts[1].toDoubleOrNull() ?: return null
            return (min * 60_000L + (sec * 1000L).toLong())
        }
    }
    val sec = clean.toDoubleOrNull() ?: return null
    return (sec * 1000L).toLong()
}
