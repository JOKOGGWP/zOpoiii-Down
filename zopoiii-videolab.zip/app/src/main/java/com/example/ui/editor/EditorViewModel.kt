package com.example.ui.editor

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.database.entities.AudioClipEntity
import com.example.data.database.entities.ClipEntity
import com.example.data.database.entities.MarkerEntity
import com.example.data.database.entities.MediaEntity
import com.example.data.database.entities.ProjectEntity
import com.example.data.database.entities.ShapeEntity
import com.example.data.database.entities.StickerEntity
import com.example.data.database.entities.SubtitleEntity
import com.example.data.database.entities.TextClipEntity
import com.example.data.database.entities.TransitionEntity
import com.example.data.model.CanvasAspectRatio
import com.example.data.model.ExportSettings
import com.example.data.model.FullProjectData
import com.example.data.repository.ProjectRepository
import com.example.editor.undo.EditorCommand
import com.example.editor.undo.UndoRedoManager
import com.example.export.ExportEngine
import com.example.export.ExportForegroundService
import com.example.export.ExportStatus
import com.example.media.AudioExtractor
import com.example.media.AudioRecorderManager
import com.example.media.MediaUtils
import com.example.media.TimelinePlayerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

enum class EditorToolTab {
    NONE,
    MEDIA,
    AUDIO,
    TEXT,
    SUBTITLE,
    STICKER,
    SHAPE,
    MARKER,
    FILTER,
    ADJUST,
    SPEED,
    CANVAS,
    TRANSITION,
    CLIP_TOOLS
}

sealed interface EditorUiEvent {
    data class ShowToast(val message: String) : EditorUiEvent
    object OpenMediaPicker : EditorUiEvent
    object OpenAudioPicker : EditorUiEvent
    object OpenCameraRecord : EditorUiEvent
}

class EditorViewModel(
    private val projectId: String,
    private val repository: ProjectRepository,
    val playerManager: TimelinePlayerManager,
    val audioRecorder: AudioRecorderManager,
    val exportEngine: ExportEngine,
    private val context: Context
) : ViewModel() {

    private val undoRedoManager = UndoRedoManager()
    val canUndo = undoRedoManager.canUndo
    val canRedo = undoRedoManager.canRedo

    private val _project = MutableStateFlow<ProjectEntity?>(null)
    val project: StateFlow<ProjectEntity?> = _project.asStateFlow()

    private val _clips = MutableStateFlow<List<ClipEntity>>(emptyList())
    val clips: StateFlow<List<ClipEntity>> = _clips.asStateFlow()

    private val _mediaMap = MutableStateFlow<Map<String, MediaEntity>>(emptyMap())
    val mediaMap: StateFlow<Map<String, MediaEntity>> = _mediaMap.asStateFlow()

    private val _textClips = MutableStateFlow<List<TextClipEntity>>(emptyList())
    val textClips: StateFlow<List<TextClipEntity>> = _textClips.asStateFlow()

    private val _audioClips = MutableStateFlow<List<AudioClipEntity>>(emptyList())
    val audioClips: StateFlow<List<AudioClipEntity>> = _audioClips.asStateFlow()

    private val _transitions = MutableStateFlow<List<TransitionEntity>>(emptyList())
    val transitions: StateFlow<List<TransitionEntity>> = _transitions.asStateFlow()

    private val _markers = MutableStateFlow<List<MarkerEntity>>(emptyList())
    val markers: StateFlow<List<MarkerEntity>> = _markers.asStateFlow()

    private val _subtitles = MutableStateFlow<List<SubtitleEntity>>(emptyList())
    val subtitles: StateFlow<List<SubtitleEntity>> = _subtitles.asStateFlow()

    private val _stickers = MutableStateFlow<List<StickerEntity>>(emptyList())
    val stickers: StateFlow<List<StickerEntity>> = _stickers.asStateFlow()

    private val _shapes = MutableStateFlow<List<ShapeEntity>>(emptyList())
    val shapes: StateFlow<List<ShapeEntity>> = _shapes.asStateFlow()

    private val _isRippleMode = MutableStateFlow(true)
    val isRippleMode: StateFlow<Boolean> = _isRippleMode.asStateFlow()

    private val _isSnapEnabled = MutableStateFlow(true)
    val isSnapEnabled: StateFlow<Boolean> = _isSnapEnabled.asStateFlow()

    private val _isAdvancedMode = MutableStateFlow(false)
    val isAdvancedMode: StateFlow<Boolean> = _isAdvancedMode.asStateFlow()

    private val _selectedClipId = MutableStateFlow<String?>(null)
    val selectedClipId: StateFlow<String?> = _selectedClipId.asStateFlow()

    private val _selectedTextClipId = MutableStateFlow<String?>(null)
    val selectedTextClipId: StateFlow<String?> = _selectedTextClipId.asStateFlow()

    private val _activeToolTab = MutableStateFlow(EditorToolTab.NONE)
    val activeToolTab: StateFlow<EditorToolTab> = _activeToolTab.asStateFlow()

    private val _timelineZoom = MutableStateFlow(100f) // dp per second
    val timelineZoom: StateFlow<Float> = _timelineZoom.asStateFlow()

    private val _events = MutableSharedFlow<EditorUiEvent>()
    val events: SharedFlow<EditorUiEvent> = _events.asSharedFlow()

    val playheadMs = playerManager.playheadMs
    val isPlaying = playerManager.isPlaying

    init {
        loadProject()
    }

    private fun loadProject() {
        viewModelScope.launch {
            val full = repository.loadFullProject(projectId) ?: return@launch
            _project.value = full.project
            _clips.value = full.clips.sortedBy { it.startTimeMs }
            _mediaMap.value = full.mediaList.associateBy { it.id }
            _textClips.value = full.textClips
            _audioClips.value = full.audioClips
            _transitions.value = full.transitions
            _markers.value = full.markers.sortedBy { it.timestampMs }
            _subtitles.value = full.subtitles.sortedBy { it.startMs }
            _stickers.value = full.stickers
            _shapes.value = full.shapes
            playerManager.setTimelineData(full.clips, full.mediaList)
        }
    }

    private fun recalculateTimelineTimings(currentClips: List<ClipEntity>): List<ClipEntity> {
        var currentStart = 0L
        return currentClips.mapIndexed { idx, clip ->
            val updated = clip.copy(
                orderIndex = idx,
                startTimeMs = currentStart
            )
            currentStart += clip.durationMs
            updated
        }
    }

    fun selectClip(clipId: String?) {
        _selectedClipId.value = clipId
        if (clipId != null) {
            _activeToolTab.value = EditorToolTab.CLIP_TOOLS
        } else if (_activeToolTab.value == EditorToolTab.CLIP_TOOLS) {
            _activeToolTab.value = EditorToolTab.NONE
        }
    }

    fun setToolTab(tab: EditorToolTab) {
        _activeToolTab.value = if (_activeToolTab.value == tab) EditorToolTab.NONE else tab
    }

    fun setTimelineZoom(zoom: Float) {
        _timelineZoom.value = zoom.coerceIn(40f, 300f)
    }

    // --- Media addition ---
    fun addMediaFiles(uris: List<Uri>) {
        viewModelScope.launch {
            val newMedia = mutableListOf<MediaEntity>()
            val newClips = mutableListOf<ClipEntity>()
            var currentStartTime = _clips.value.maxOfOrNull { it.startTimeMs + it.durationMs } ?: 0L

            uris.forEachIndexed { i, rawUri ->
                val localUri = MediaUtils.importMediaToProject(context, projectId, rawUri)
                val meta = MediaUtils.extractMetadata(context, localUri)
                val mId = UUID.randomUUID().toString()
                val mediaEntity = MediaEntity(
                    id = mId,
                    projectId = projectId,
                    uri = localUri.toString(),
                    type = if (meta.isVideo) "video" else "image",
                    durationMs = meta.durationMs,
                    width = meta.width,
                    height = meta.height,
                    rotation = meta.rotation
                )
                newMedia.add(mediaEntity)

                val cId = UUID.randomUUID().toString()
                val clipEntity = ClipEntity(
                    id = cId,
                    projectId = projectId,
                    mediaId = mId,
                    trackId = "track_main_video",
                    orderIndex = _clips.value.size + i,
                    startTimeMs = currentStartTime,
                    durationMs = meta.durationMs,
                    sourceStartMs = 0L,
                    sourceEndMs = meta.durationMs,
                    filterName = "ORIGINAL"
                )
                newClips.add(clipEntity)
                currentStartTime += meta.durationMs
            }

            val updatedMediaMap = _mediaMap.value.toMutableMap().apply {
                newMedia.forEach { put(it.id, it) }
            }
            val updatedClips = recalculateTimelineTimings(_clips.value + newClips)

            _mediaMap.value = updatedMediaMap
            _clips.value = updatedClips
            playerManager.setTimelineData(updatedClips, updatedMediaMap.values.toList())
            autosave()
            _events.emit(EditorUiEvent.ShowToast("${newClips.size} media ditambahkan"))
        }
    }

    // --- Split Clip at Playhead ---
    fun splitClipAtPlayhead() {
        val currentPlayhead = playheadMs.value
        val clip = _clips.value.firstOrNull {
            currentPlayhead > it.startTimeMs && currentPlayhead < (it.startTimeMs + it.durationMs)
        } ?: run {
            viewModelScope.launch { _events.emit(EditorUiEvent.ShowToast("Arahkan garis waktu (playhead) ke dalam klip untuk memotong.")) }
            return
        }

        val offsetInClipMs = currentPlayhead - clip.startTimeMs
        if (offsetInClipMs < 100 || (clip.durationMs - offsetInClipMs) < 100) {
            viewModelScope.launch { _events.emit(EditorUiEvent.ShowToast("Posisi potong terlalu dekat dengan batas klip.")) }
            return
        }

        val sourceOffsetMs = (offsetInClipMs * clip.speed).toLong()
        val splitSourcePoint = clip.sourceStartMs + sourceOffsetMs

        val partA = clip.copy(
            id = UUID.randomUUID().toString(),
            durationMs = offsetInClipMs,
            sourceEndMs = splitSourcePoint
        )

        val partB = clip.copy(
            id = UUID.randomUUID().toString(),
            startTimeMs = currentPlayhead,
            durationMs = clip.durationMs - offsetInClipMs,
            sourceStartMs = splitSourcePoint
        )

        val clipIndex = _clips.value.indexOfFirst { it.id == clip.id }
        val updatedClips = _clips.value.toMutableList().apply {
            removeAt(clipIndex)
            add(clipIndex, partB)
            add(clipIndex, partA)
        }
        val finalClips = recalculateTimelineTimings(updatedClips)

        undoRedoManager.push(EditorCommand.SplitClip(clip, partA, partB))
        _clips.value = finalClips
        _selectedClipId.value = partA.id
        playerManager.setTimelineData(finalClips, _mediaMap.value.values.toList())
        autosave()
    }

    // --- Trim Selected Clip ---
    fun trimSelectedClip(newSourceStartMs: Long, newSourceEndMs: Long) {
        val selectedId = _selectedClipId.value ?: return
        val clip = _clips.value.firstOrNull { it.id == selectedId } ?: return
        if (newSourceEndMs - newSourceStartMs < 200) return

        val newDuration = ((newSourceEndMs - newSourceStartMs) / clip.speed).toLong()
        val updatedClip = clip.copy(
            sourceStartMs = newSourceStartMs,
            sourceEndMs = newSourceEndMs,
            durationMs = newDuration
        )

        undoRedoManager.push(
            EditorCommand.TrimClip(
                clipId = clip.id,
                oldSourceStart = clip.sourceStartMs,
                oldSourceEnd = clip.sourceEndMs,
                oldDuration = clip.durationMs,
                newSourceStart = newSourceStartMs,
                newSourceEnd = newSourceEndMs,
                newDuration = newDuration
            )
        )

        val updatedClips = recalculateTimelineTimings(
            _clips.value.map { if (it.id == clip.id) updatedClip else it }
        )
        _clips.value = updatedClips
        playerManager.setTimelineData(updatedClips, _mediaMap.value.values.toList())
        autosave()
    }

    // --- Delete Clip ---
    fun deleteSelectedClip() {
        val selectedId = _selectedClipId.value ?: return
        val clipIndex = _clips.value.indexOfFirst { it.id == selectedId }
        if (clipIndex == -1) return

        val deletedClip = _clips.value[clipIndex]
        val remaining = _clips.value.toMutableList().apply { removeAt(clipIndex) }
        val finalClips = recalculateTimelineTimings(remaining)

        undoRedoManager.push(EditorCommand.DeleteClip(deletedClip, clipIndex))
        _clips.value = finalClips
        _selectedClipId.value = null
        _activeToolTab.value = EditorToolTab.NONE
        playerManager.setTimelineData(finalClips, _mediaMap.value.values.toList())
        autosave()
    }

    // --- Duplicate Clip ---
    fun duplicateSelectedClip() {
        val selectedId = _selectedClipId.value ?: return
        val clipIndex = _clips.value.indexOfFirst { it.id == selectedId }
        if (clipIndex == -1) return

        val sourceClip = _clips.value[clipIndex]
        val duplicatedClip = sourceClip.copy(
            id = UUID.randomUUID().toString()
        )

        val updated = _clips.value.toMutableList().apply {
            add(clipIndex + 1, duplicatedClip)
        }
        val finalClips = recalculateTimelineTimings(updated)

        undoRedoManager.push(EditorCommand.AddClip(duplicatedClip))
        _clips.value = finalClips
        _selectedClipId.value = duplicatedClip.id
        playerManager.setTimelineData(finalClips, _mediaMap.value.values.toList())
        autosave()
    }

    // --- Rotate and Flip ---
    fun rotateSelectedClip() {
        val selectedId = _selectedClipId.value ?: return
        val clip = _clips.value.firstOrNull { it.id == selectedId } ?: return
        val nextRotation = (clip.rotation + 90f) % 360f
        val updated = clip.copy(rotation = nextRotation)
        updateSingleClip(updated)
    }

    fun flipHorizontalSelectedClip() {
        val selectedId = _selectedClipId.value ?: return
        val clip = _clips.value.firstOrNull { it.id == selectedId } ?: return
        updateSingleClip(clip.copy(isFlippedHorizontal = !clip.isFlippedHorizontal))
    }

    fun flipVerticalSelectedClip() {
        val selectedId = _selectedClipId.value ?: return
        val clip = _clips.value.firstOrNull { it.id == selectedId } ?: return
        updateSingleClip(clip.copy(isFlippedVertical = !clip.isFlippedVertical))
    }

    // --- Speed ---
    fun setSpeedSelectedClip(newSpeed: Float) {
        val selectedId = _selectedClipId.value ?: return
        val clip = _clips.value.firstOrNull { it.id == selectedId } ?: return
        val newDuration = ((clip.sourceEndMs - clip.sourceStartMs) / newSpeed).toLong().coerceAtLeast(100L)
        val updated = clip.copy(speed = newSpeed, durationMs = newDuration)

        undoRedoManager.push(
            EditorCommand.ChangeSpeed(
                clipId = clip.id,
                oldSpeed = clip.speed,
                oldDuration = clip.durationMs,
                newSpeed = newSpeed,
                newDuration = newDuration
            )
        )

        val updatedClips = recalculateTimelineTimings(
            _clips.value.map { if (it.id == clip.id) updated else it }
        )
        _clips.value = updatedClips
        playerManager.setTimelineData(updatedClips, _mediaMap.value.values.toList())
        autosave()
    }

    // --- Volume ---
    fun setVolumeSelectedClip(volume: Float) {
        val selectedId = _selectedClipId.value ?: return
        val clip = _clips.value.firstOrNull { it.id == selectedId } ?: return
        updateSingleClip(clip.copy(volume = volume.coerceIn(0f, 2f)))
    }

    // --- Filter & Adjustment ---
    fun setFilterSelectedClip(filterName: String) {
        val selectedId = _selectedClipId.value ?: return
        val clip = _clips.value.firstOrNull { it.id == selectedId } ?: return
        undoRedoManager.push(EditorCommand.ChangeFilter(clip.id, clip.filterName, filterName))
        updateSingleClip(clip.copy(filterName = filterName))
    }

    fun setAdjustmentSelectedClip(brightness: Float, contrast: Float, saturation: Float) {
        val selectedId = _selectedClipId.value ?: return
        val clip = _clips.value.firstOrNull { it.id == selectedId } ?: return
        undoRedoManager.push(
            EditorCommand.ChangeAdjustment(
                clip.id,
                clip.brightness, clip.contrast, clip.saturation,
                brightness, contrast, saturation
            )
        )
        updateSingleClip(clip.copy(brightness = brightness, contrast = contrast, saturation = saturation))
    }

    // --- Freeze Frame ---
    fun freezeFrameAtPlayhead(durationMs: Long = 3000L) {
        val currentPlayhead = playheadMs.value
        val clip = _clips.value.firstOrNull {
            currentPlayhead >= it.startTimeMs && currentPlayhead <= (it.startTimeMs + it.durationMs)
        } ?: run {
            viewModelScope.launch { _events.emit(EditorUiEvent.ShowToast("Arahkan garis waktu ke dalam video.")) }
            return
        }

        viewModelScope.launch {
            val media = _mediaMap.value[clip.mediaId] ?: return@launch
            val offsetInClipMs = currentPlayhead - clip.startTimeMs
            val sourceTimeUs = (clip.sourceStartMs + (offsetInClipMs * clip.speed).toLong()) * 1000L

            val frameBm = com.example.media.ThumbnailLoader.getFrameAtTime(
                context,
                Uri.parse(media.uri),
                sourceTimeUs,
                media.width,
                media.height
            )

            if (frameBm != null) {
                val freezeDir = File(context.cacheDir, "freeze_frames").apply { mkdirs() }
                val freezeFile = File(freezeDir, "freeze_${UUID.randomUUID()}.jpg")
                withContext(Dispatchers.IO) {
                    freezeFile.outputStream().use { out ->
                        frameBm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, out)
                    }
                }

                val freezeMediaId = UUID.randomUUID().toString()
                val freezeMedia = MediaEntity(
                    id = freezeMediaId,
                    projectId = projectId,
                    uri = Uri.fromFile(freezeFile).toString(),
                    type = "image",
                    durationMs = durationMs,
                    width = media.width,
                    height = media.height
                )

                val freezeClipId = UUID.randomUUID().toString()
                val freezeClip = ClipEntity(
                    id = freezeClipId,
                    projectId = projectId,
                    mediaId = freezeMediaId,
                    startTimeMs = currentPlayhead,
                    durationMs = durationMs,
                    sourceStartMs = 0L,
                    sourceEndMs = durationMs
                )

                val currentIdx = _clips.value.indexOfFirst { it.id == clip.id }
                val updatedClips = _clips.value.toMutableList().apply {
                    add(currentIdx + 1, freezeClip)
                }
                val finalClips = recalculateTimelineTimings(updatedClips)

                _mediaMap.value = _mediaMap.value + (freezeMediaId to freezeMedia)
                _clips.value = finalClips
                playerManager.setTimelineData(finalClips, _mediaMap.value.values.toList())
                autosave()
                _events.emit(EditorUiEvent.ShowToast("Frame beku ($durationMs ms) ditambahkan"))
            } else {
                _events.emit(EditorUiEvent.ShowToast("Gagal mengambil frame dari video."))
            }
        }
    }

    // --- Extract Audio ---
    fun extractAudioFromSelectedClip() {
        val selectedId = _selectedClipId.value ?: return
        val clip = _clips.value.firstOrNull { it.id == selectedId } ?: return
        val media = _mediaMap.value[clip.mediaId] ?: return

        viewModelScope.launch {
            _events.emit(EditorUiEvent.ShowToast("Mengekstrak audio dari video..."))
            val audioFile = AudioExtractor.extractAudioFromVideo(context, Uri.parse(media.uri))
            if (audioFile != null) {
                val audioId = UUID.randomUUID().toString()
                val newAudio = AudioClipEntity(
                    id = audioId,
                    projectId = projectId,
                    uri = Uri.fromFile(audioFile).toString(),
                    name = "Audio Ekstrak",
                    startTimeMs = clip.startTimeMs,
                    durationMs = clip.durationMs,
                    sourceStartMs = clip.sourceStartMs,
                    sourceEndMs = clip.sourceEndMs,
                    volume = 1.0f
                )
                // Mute original video clip
                updateSingleClip(clip.copy(volume = 0f))
                _audioClips.value = _audioClips.value + newAudio
                undoRedoManager.push(EditorCommand.AddAudio(newAudio))
                autosave()
                _events.emit(EditorUiEvent.ShowToast("Audio berhasil diekstrak ke timeline!"))
            } else {
                _events.emit(EditorUiEvent.ShowToast("Gagal mengekstrak audio."))
            }
        }
    }

    // --- Voice Over ---
    fun addRecordedVoiceOver(audioFile: File, durationMs: Long) {
        val newAudio = AudioClipEntity(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            uri = Uri.fromFile(audioFile).toString(),
            name = "Rekaman Suara",
            startTimeMs = playheadMs.value,
            durationMs = durationMs,
            sourceStartMs = 0L,
            sourceEndMs = durationMs,
            volume = 1.0f,
            isVoiceOver = true
        )
        _audioClips.value = _audioClips.value + newAudio
        undoRedoManager.push(EditorCommand.AddAudio(newAudio))
        autosave()
    }

    // --- Text Clips ---
    fun addTextClip(text: String, font: String = "Roboto", colorHex: Long = 0xFFFFFFFF) {
        val newText = TextClipEntity(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            text = text.ifBlank { "Teks Anda" },
            font = font,
            sizeSp = 24f,
            colorHex = colorHex,
            startTimeMs = playheadMs.value,
            durationMs = 3000L
        )
        _textClips.value = _textClips.value + newText
        undoRedoManager.push(EditorCommand.AddText(newText))
        autosave()
    }

    fun updateTextClip(updated: TextClipEntity) {
        _textClips.value = _textClips.value.map { if (it.id == updated.id) updated else it }
        autosave()
    }

    fun deleteTextClip(id: String) {
        val target = _textClips.value.firstOrNull { it.id == id } ?: return
        undoRedoManager.push(EditorCommand.DeleteText(target))
        _textClips.value = _textClips.value.filter { it.id != id }
        autosave()
    }

    // --- Transitions ---
    fun setTransition(clipBeforeId: String, clipAfterId: String, type: String, durationMs: Long) {
        val trans = TransitionEntity(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            clipBeforeId = clipBeforeId,
            clipAfterId = clipAfterId,
            type = type,
            durationMs = durationMs
        )
        _transitions.value = _transitions.value.filterNot {
            it.clipBeforeId == clipBeforeId && it.clipAfterId == clipAfterId
        } + trans
        autosave()
    }

    // --- Canvas Ratio ---
    fun setCanvasRatio(ratio: CanvasAspectRatio) {
        val current = _project.value ?: return
        val (w, h) = when (ratio) {
            CanvasAspectRatio.RATIO_9_16 -> 1080 to 1920
            CanvasAspectRatio.RATIO_16_9 -> 1920 to 1080
            CanvasAspectRatio.RATIO_1_1 -> 1080 to 1080
            CanvasAspectRatio.RATIO_4_3 -> 1440 to 1080
            CanvasAspectRatio.RATIO_3_4 -> 1080 to 1440
            CanvasAspectRatio.RATIO_21_9 -> 2560 to 1080
            CanvasAspectRatio.RATIO_9_21 -> 1080 to 2560
            CanvasAspectRatio.RATIO_2_1 -> 2160 to 1080
            CanvasAspectRatio.RATIO_1_2 -> 1080 to 2160
            CanvasAspectRatio.CUSTOM -> 1080 to 1920
            else -> 1080 to 1920
        }
        _project.value = current.copy(
            canvasWidth = w,
            canvasHeight = h,
            canvasRatio = ratio.label
        )
        autosave()
    }

    private fun updateSingleClip(updated: ClipEntity) {
        val updatedList = _clips.value.map { if (it.id == updated.id) updated else it }
        _clips.value = updatedList
        playerManager.setTimelineData(updatedList, _mediaMap.value.values.toList())
        autosave()
    }

    // --- Undo / Redo Execution ---
    fun undo() {
        val cmd = undoRedoManager.popUndo() ?: return
        when (cmd) {
            is EditorCommand.SplitClip -> {
                // Revert split: restore originalClip, remove partA & partB
                val filtered = _clips.value.filterNot { it.id == cmd.partA.id || it.id == cmd.partB.id }
                val restored = recalculateTimelineTimings(filtered + cmd.originalClip)
                _clips.value = restored
                playerManager.setTimelineData(restored, _mediaMap.value.values.toList())
            }
            is EditorCommand.DeleteClip -> {
                val restored = _clips.value.toMutableList().apply {
                    add(cmd.originalIndex.coerceIn(0, size), cmd.deletedClip)
                }
                val finalClips = recalculateTimelineTimings(restored)
                _clips.value = finalClips
                playerManager.setTimelineData(finalClips, _mediaMap.value.values.toList())
            }
            is EditorCommand.AddClip -> {
                val filtered = _clips.value.filterNot { it.id == cmd.clip.id }
                val restored = recalculateTimelineTimings(filtered)
                _clips.value = restored
                playerManager.setTimelineData(restored, _mediaMap.value.values.toList())
            }
            is EditorCommand.TrimClip -> {
                val restored = _clips.value.map {
                    if (it.id == cmd.clipId) it.copy(
                        sourceStartMs = cmd.oldSourceStart,
                        sourceEndMs = cmd.oldSourceEnd,
                        durationMs = cmd.oldDuration
                    ) else it
                }
                val finalClips = recalculateTimelineTimings(restored)
                _clips.value = finalClips
                playerManager.setTimelineData(finalClips, _mediaMap.value.values.toList())
            }
            is EditorCommand.ChangeSpeed -> {
                val restored = _clips.value.map {
                    if (it.id == cmd.clipId) it.copy(speed = cmd.oldSpeed, durationMs = cmd.oldDuration) else it
                }
                val finalClips = recalculateTimelineTimings(restored)
                _clips.value = finalClips
                playerManager.setTimelineData(finalClips, _mediaMap.value.values.toList())
            }
            is EditorCommand.ChangeFilter -> {
                updateSingleClip(_clips.value.first { it.id == cmd.clipId }.copy(filterName = cmd.oldFilter))
            }
            is EditorCommand.ChangeAdjustment -> {
                updateSingleClip(
                    _clips.value.first { it.id == cmd.clipId }.copy(
                        brightness = cmd.oldB,
                        contrast = cmd.oldC,
                        saturation = cmd.oldS
                    )
                )
            }
            is EditorCommand.AddText -> {
                _textClips.value = _textClips.value.filterNot { it.id == cmd.textClip.id }
            }
            is EditorCommand.DeleteText -> {
                _textClips.value = _textClips.value + cmd.textClip
            }
            is EditorCommand.AddAudio -> {
                _audioClips.value = _audioClips.value.filterNot { it.id == cmd.audioClip.id }
            }
            is EditorCommand.DeleteAudio -> {
                _audioClips.value = _audioClips.value + cmd.audioClip
            }
        }
        autosave()
    }

    fun redo() {
        val cmd = undoRedoManager.popRedo() ?: return
        when (cmd) {
            is EditorCommand.SplitClip -> {
                val filtered = _clips.value.filterNot { it.id == cmd.originalClip.id }
                val updated = recalculateTimelineTimings(filtered + cmd.partA + cmd.partB)
                _clips.value = updated
                playerManager.setTimelineData(updated, _mediaMap.value.values.toList())
            }
            is EditorCommand.DeleteClip -> {
                val filtered = _clips.value.filterNot { it.id == cmd.deletedClip.id }
                val updated = recalculateTimelineTimings(filtered)
                _clips.value = updated
                playerManager.setTimelineData(updated, _mediaMap.value.values.toList())
            }
            is EditorCommand.AddClip -> {
                val updated = recalculateTimelineTimings(_clips.value + cmd.clip)
                _clips.value = updated
                playerManager.setTimelineData(updated, _mediaMap.value.values.toList())
            }
            is EditorCommand.TrimClip -> {
                val restored = _clips.value.map {
                    if (it.id == cmd.clipId) it.copy(
                        sourceStartMs = cmd.newSourceStart,
                        sourceEndMs = cmd.newSourceEnd,
                        durationMs = cmd.newDuration
                    ) else it
                }
                val finalClips = recalculateTimelineTimings(restored)
                _clips.value = finalClips
                playerManager.setTimelineData(finalClips, _mediaMap.value.values.toList())
            }
            is EditorCommand.ChangeSpeed -> {
                val restored = _clips.value.map {
                    if (it.id == cmd.clipId) it.copy(speed = cmd.newSpeed, durationMs = cmd.newDuration) else it
                }
                val finalClips = recalculateTimelineTimings(restored)
                _clips.value = finalClips
                playerManager.setTimelineData(finalClips, _mediaMap.value.values.toList())
            }
            is EditorCommand.ChangeFilter -> {
                updateSingleClip(_clips.value.first { it.id == cmd.clipId }.copy(filterName = cmd.newFilter))
            }
            is EditorCommand.ChangeAdjustment -> {
                updateSingleClip(
                    _clips.value.first { it.id == cmd.clipId }.copy(
                        brightness = cmd.newB,
                        contrast = cmd.newC,
                        saturation = cmd.newS
                    )
                )
            }
            is EditorCommand.AddText -> {
                _textClips.value = _textClips.value + cmd.textClip
            }
            is EditorCommand.DeleteText -> {
                _textClips.value = _textClips.value.filterNot { it.id == cmd.textClip.id }
            }
            is EditorCommand.AddAudio -> {
                _audioClips.value = _audioClips.value + cmd.audioClip
            }
            is EditorCommand.DeleteAudio -> {
                _audioClips.value = _audioClips.value.filterNot { it.id == cmd.audioClip.id }
            }
        }
        autosave()
    }

    fun startExport(settings: ExportSettings) {
        viewModelScope.launch {
            ExportForegroundService.startService(context)
            exportEngine.startExport(_clips.value, _mediaMap.value, settings)
        }
    }

    // --- Markers ---
    fun addMarkerAtPlayhead(name: String = "Marker", colorHex: Long = 0xFFFFD700, note: String = "") {
        val currentMs = playheadMs.value
        val newMarker = MarkerEntity(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            timestampMs = currentMs,
            name = name,
            colorHex = colorHex,
            note = note
        )
        _markers.value = (_markers.value + newMarker).sortedBy { it.timestampMs }
        autosave()
        viewModelScope.launch {
            _events.emit(EditorUiEvent.ShowToast("Marker ditambahkan pada ${MediaUtils.formatTime(currentMs)}"))
        }
    }

    fun deleteMarker(markerId: String) {
        _markers.value = _markers.value.filterNot { it.id == markerId }
        autosave()
    }

    // --- Subtitles ---
    fun addSubtitleAtPlayhead(text: String, durationMs: Long = 2500L) {
        val currentMs = playheadMs.value
        val newSub = SubtitleEntity(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            startMs = currentMs,
            endMs = currentMs + durationMs,
            text = text
        )
        _subtitles.value = (_subtitles.value + newSub).sortedBy { it.startMs }
        autosave()
        viewModelScope.launch {
            _events.emit(EditorUiEvent.ShowToast("Subtitel ditambahkan"))
        }
    }

    fun updateSubtitle(updated: SubtitleEntity) {
        _subtitles.value = _subtitles.value.map { if (it.id == updated.id) updated else it }.sortedBy { it.startMs }
        autosave()
    }

    fun deleteSubtitle(subtitleId: String) {
        _subtitles.value = _subtitles.value.filterNot { it.id == subtitleId }
        autosave()
    }

    // --- Stickers & Shapes ---
    fun addSticker(uriOrName: String) {
        val currentMs = playheadMs.value
        val newSticker = StickerEntity(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            uriOrName = uriOrName,
            startTimeMs = currentMs,
            durationMs = 3000L
        )
        _stickers.value = _stickers.value + newSticker
        autosave()
    }

    fun deleteSticker(stickerId: String) {
        _stickers.value = _stickers.value.filterNot { it.id == stickerId }
        autosave()
    }

    fun addShape(shapeType: String, fillHex: Long = 0xFFFF5376) {
        val currentMs = playheadMs.value
        val newShape = ShapeEntity(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            shapeType = shapeType,
            fillHex = fillHex,
            startTimeMs = currentMs,
            durationMs = 3000L
        )
        _shapes.value = _shapes.value + newShape
        autosave()
    }

    fun deleteShape(shapeId: String) {
        _shapes.value = _shapes.value.filterNot { it.id == shapeId }
        autosave()
    }

    // --- Custom Canvas Dimensions ---
    fun setCustomCanvasDimensions(width: Int, height: Int, ratioLabel: String = "Custom") {
        val current = _project.value ?: return
        val clampedW = width.coerceIn(1, 8192)
        val clampedH = height.coerceIn(1, 8192)
        _project.value = current.copy(
            canvasWidth = clampedW,
            canvasHeight = clampedH,
            canvasRatio = ratioLabel
        )
        autosave()
    }

    // --- Transport & Precision Control ---
    fun seekTo(timeMs: Long) {
        playerManager.seekTo(timeMs.coerceAtLeast(0L))
    }

    fun stepFrame(deltaFrames: Int, fps: Int = 30) {
        val frameDurationMs = (1000f / fps).toLong().coerceAtLeast(1L)
        val target = (playheadMs.value + deltaFrames * frameDurationMs).coerceAtLeast(0L)
        seekTo(target)
    }

    fun toggleRippleMode() {
        _isRippleMode.value = !_isRippleMode.value
        viewModelScope.launch {
            _events.emit(EditorUiEvent.ShowToast("Ripple editing: ${if (_isRippleMode.value) "Aktif" else "Nonaktif"}"))
        }
    }

    fun toggleSnap() {
        _isSnapEnabled.value = !_isSnapEnabled.value
        viewModelScope.launch {
            _events.emit(EditorUiEvent.ShowToast("Magnet / Snap: ${if (_isSnapEnabled.value) "Aktif" else "Nonaktif"}"))
        }
    }

    fun toggleAdvancedMode() {
        _isAdvancedMode.value = !_isAdvancedMode.value
    }

    // --- Audio Ducking & Fade ---
    fun setAudioFade(clipId: String, fadeInMs: Long, fadeOutMs: Long) {
        _audioClips.value = _audioClips.value.map {
            if (it.id == clipId) it.copy(fadeInMs = fadeInMs, fadeOutMs = fadeOutMs) else it
        }
        autosave()
    }

    fun applyAudioDucking(targetDuckVolume: Float = 0.3f) {
        // Automatically duck music clips during voiceover or video clips
        _audioClips.value = _audioClips.value.map { a ->
            if (!a.isVoiceOver) a.copy(volume = targetDuckVolume) else a
        }
        autosave()
        viewModelScope.launch {
            _events.emit(EditorUiEvent.ShowToast("Audio Ducking diterapkan ke trek musik"))
        }
    }

    private fun autosave() {
        val currentProj = _project.value ?: return
        viewModelScope.launch {
            repository.saveFullProject(
                FullProjectData(
                    project = currentProj,
                    mediaList = _mediaMap.value.values.toList(),
                    clips = _clips.value,
                    textClips = _textClips.value,
                    audioClips = _audioClips.value,
                    transitions = _transitions.value,
                    markers = _markers.value,
                    subtitles = _subtitles.value,
                    stickers = _stickers.value,
                    shapes = _shapes.value
                )
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
        audioRecorder.cancel()
    }
}

class EditorViewModelFactory(
    private val projectId: String,
    private val repository: ProjectRepository,
    private val context: Context
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val playerManager = TimelinePlayerManager(context)
        val audioRecorder = AudioRecorderManager(context)
        val exportEngine = ExportEngine(context)
        return EditorViewModel(
            projectId = projectId,
            repository = repository,
            playerManager = playerManager,
            audioRecorder = audioRecorder,
            exportEngine = exportEngine,
            context = context
        ) as T
    }
}
