package com.example.ui.editor.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExportBitrate
import com.example.data.model.ExportCodec
import com.example.data.model.ExportFps
import com.example.data.model.ExportResolution
import com.example.data.model.ExportSettings
import com.example.export.ExportEngine
import com.example.export.ExportStatus
import com.example.export.StorageUtils
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportSheet(
    exportEngine: ExportEngine,
    totalDurationMs: Long,
    onStartExport: (ExportSettings) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val status by exportEngine.status.collectAsState()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var selectedResolution by remember { mutableStateOf(ExportResolution.RES_1080P) }
    var selectedFps by remember { mutableStateOf(ExportFps.FPS_30) }
    var selectedCodec by remember { mutableStateOf(ExportCodec.H264) }
    var selectedBitrate by remember { mutableStateOf(ExportBitrate.AUTO) }

    ModalBottomSheet(
        onDismissRequest = {
            if (status is ExportStatus.Exporting) {
                exportEngine.cancel()
            }
            exportEngine.reset()
            onDismiss()
        },
        sheetState = sheetState,
        containerColor = DarkSurfaceElevated
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (val s = status) {
                is ExportStatus.Idle -> {
                    // --- Settings Config View ---
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ekspor Video MP4",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
                        }
                    }

                    // Resolution selector
                    Text("Resolusi Video", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ExportResolution.entries.forEach { res ->
                            val isSel = (res == selectedResolution)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) ElectricCyan.copy(alpha = 0.2f) else DarkSurfaceVariant)
                                    .border(1.5.dp, if (isSel) ElectricCyan else DarkOutline, RoundedCornerShape(8.dp))
                                    .clickable { selectedResolution = res }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = res.label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) ElectricCyan else TextPrimary
                                )
                            }
                        }
                    }

                    // FPS selector
                    Text("Kecepatan Frame (FPS)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ExportFps.entries.forEach { fps ->
                            val isSel = (fps == selectedFps)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) ElectricCyan.copy(alpha = 0.2f) else DarkSurfaceVariant)
                                    .border(1.5.dp, if (isSel) ElectricCyan else DarkOutline, RoundedCornerShape(8.dp))
                                    .clickable { selectedFps = fps }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = fps.label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) ElectricCyan else TextPrimary
                                )
                            }
                        }
                    }

                    // Codec selector
                    Text("Format Codec", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ExportCodec.entries.forEach { codec ->
                            val isSel = (codec == selectedCodec)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) NeonViolet.copy(alpha = 0.2f) else DarkSurfaceVariant)
                                    .border(1.5.dp, if (isSel) NeonViolet else DarkOutline, RoundedCornerShape(8.dp))
                                    .clickable { selectedCodec = codec }
                                    .padding(vertical = 8.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = codec.label,
                                    fontSize = 11.sp,
                                    color = if (isSel) NeonViolet else TextPrimary
                                )
                            }
                        }
                    }

                    // Storage Estimation Card
                    val estBytes = StorageUtils.estimateExportSizeBytes(
                        totalDurationMs,
                        selectedResolution.width,
                        selectedResolution.height,
                        selectedFps.fpsValue
                    )
                    val estMb = estBytes / (1024 * 1024)
                    val freeBytes = StorageUtils.getAvailableStorageBytes()
                    val freeGb = String.format("%.1f", freeBytes / (1024f * 1024f * 1024f))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Perkiraan Ukuran: ~$estMb MB",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Penyimpanan Tersedia: $freeGb GB (Cukup)",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Start Button
                    Button(
                        onClick = {
                            val settings = ExportSettings(
                                resolutionMode = "PRESET",
                                customWidth = selectedResolution.width,
                                customHeight = selectedResolution.height,
                                fps = selectedFps.fpsValue,
                                bitrateMode = if (selectedBitrate == ExportBitrate.AUTO) "AUTO" else "CUSTOM",
                                customBitrateMbps = when (selectedBitrate) {
                                    ExportBitrate.LOW -> 2
                                    ExportBitrate.MEDIUM -> 8
                                    ExportBitrate.HIGH -> 16
                                    ExportBitrate.ULTRA -> 30
                                    else -> 8
                                },
                                videoCodec = if (selectedCodec == ExportCodec.HEVC) "HEVC" else "H264"
                            )
                            onStartExport(settings)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Mulai Ekspor Sekarang", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }

                is ExportStatus.Exporting -> {
                    // --- Progress View ---
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier.size(80.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                progress = { s.progressPercent / 100f },
                                color = ElectricCyan,
                                trackColor = DarkOutline,
                                strokeWidth = 6.dp,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                text = "${s.progressPercent}%",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextPrimary
                            )
                        }

                        Text(
                            text = "Sedang Merender Video...",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
                        )

                        Text(
                            text = if (s.etaSeconds > 0) "Perkiraan sisa waktu: ${s.etaSeconds} detik" else "Menyelesaikan berkas...",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        Text(
                            text = "Aman keluar aplikasi — ekspor berjalan melalui Foreground Service",
                            fontSize = 11.sp,
                            color = TextTertiary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = { exportEngine.cancel() },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCoral)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Batalkan Ekspor")
                        }
                    }
                }

                is ExportStatus.Success -> {
                    // --- Success View ---
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(EmeraldGreen.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = EmeraldGreen,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Text(
                            text = "Ekspor Selesai!",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
                        )

                        Text(
                            text = "Disimpan di folder Movies/zOpoiii VideoLab/",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = {
                                    val targetUri = s.savedMediaUri ?: Uri.fromFile(s.outputFile)
                                    StorageUtils.openVideoFile(context, targetUri)
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color.Black),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Putar Video")
                            }

                            Button(
                                onClick = {
                                    val targetUri = s.savedMediaUri ?: Uri.fromFile(s.outputFile)
                                    StorageUtils.openShareSheet(context, targetUri)
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = NeonViolet, contentColor = Color.White),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Bagikan")
                            }
                        }

                        TextButton(
                            onClick = {
                                exportEngine.reset()
                                onDismiss()
                            }
                        ) {
                            Text("Selesai", color = TextSecondary)
                        }
                    }
                }

                is ExportStatus.Error -> {
                    // --- Error View ---
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = NeonCoral,
                            modifier = Modifier.size(48.dp)
                        )
                        Text("Ekspor Gagal", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text(s.errorMessage, fontSize = 12.sp, color = TextSecondary)

                        Button(
                            onClick = { exportEngine.reset() },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant)
                        ) {
                            Text("Coba Lagi")
                        }
                    }
                }

                is ExportStatus.Cancelled -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Ekspor Dibatalkan", style = MaterialTheme.typography.titleMedium)
                        Button(
                            onClick = { exportEngine.reset() },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant)
                        ) {
                            Text("Kembali ke Pengaturan")
                        }
                    }
                }
            }
        }
    }
}
