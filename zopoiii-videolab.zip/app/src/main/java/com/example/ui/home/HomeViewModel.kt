package com.example.ui.home

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.database.entities.ProjectEntity
import com.example.data.model.CanvasAspectRatio
import com.example.data.repository.ProjectRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

sealed interface HomeEvent {
    data class NavigateToEditor(val projectId: String) : HomeEvent
    data class ShowToast(val message: String) : HomeEvent
}

class HomeViewModel(private val repository: ProjectRepository) : ViewModel() {

    val projects: StateFlow<List<ProjectEntity>> = repository.allProjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _events = MutableSharedFlow<HomeEvent>()
    val events: SharedFlow<HomeEvent> = _events.asSharedFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun createProject(name: String, uris: List<Uri>, ratio: CanvasAspectRatio) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val projectId = repository.createNewProject(name, uris, ratio)
                _events.emit(HomeEvent.NavigateToEditor(projectId))
            } catch (e: Exception) {
                _events.emit(HomeEvent.ShowToast("Gagal membuat proyek: ${e.message}"))
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun renameProject(projectId: String, newName: String) {
        viewModelScope.launch {
            repository.renameProject(projectId, newName)
            _events.emit(HomeEvent.ShowToast("Nama proyek diperbarui"))
        }
    }

    fun duplicateProject(projectId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.duplicateProject(projectId)
                _events.emit(HomeEvent.ShowToast("Proyek berhasil digandakan"))
            } catch (e: Exception) {
                _events.emit(HomeEvent.ShowToast("Gagal menggandakan proyek: ${e.message}"))
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            _events.emit(HomeEvent.ShowToast("Proyek dihapus"))
        }
    }

    fun exportProjectPackage(projectId: String, onExported: (File) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val file = repository.exportProjectPackage(projectId)
            _isLoading.value = false
            if (file != null) {
                onExported(file)
            } else {
                _events.emit(HomeEvent.ShowToast("Gagal mengekspor berkas proyek"))
            }
        }
    }

    fun importProject(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            val newProjectId = repository.importProjectPackage(uri)
            _isLoading.value = false
            if (newProjectId != null) {
                _events.emit(HomeEvent.ShowToast("Proyek berhasil diimpor!"))
                _events.emit(HomeEvent.NavigateToEditor(newProjectId))
            } else {
                _events.emit(HomeEvent.ShowToast("Berkas proyek tidak valid atau rusak."))
            }
        }
    }
}

class HomeViewModelFactory(
    private val repository: ProjectRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return HomeViewModel(repository) as T
    }
}
