package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// zOpoiii VideoLab 2026 Dark-First Professional Palette
val DarkBackground = Color(0xFF0A0D14)
val DarkSurface = Color(0xFF131822)
val DarkSurfaceVariant = Color(0xFF1C2333)
val DarkSurfaceElevated = Color(0xFF232C3F)
val DarkOutline = Color(0xFF2F3B52)

val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDark = Color(0xFF009AB3)
val NeonViolet = Color(0xFF8B5CF6)
val NeonCoral = Color(0xFFFF5376)
val GoldenAmber = Color(0xFFFFB300)
val EmeraldGreen = Color(0xFF10B981)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// Light fallback colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF2F6)
val LightOutline = Color(0xFFCBD5E1)
val TextDarkPrimary = Color(0xFF0F172A)
