package com.example.ui.editor.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.CopyAll
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Filter
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MovieFilter
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.entities.ClipEntity
import com.example.data.model.CanvasAspectRatio
import com.example.data.model.FilterType
import com.example.data.model.SpeedPreset
import com.example.data.model.StickerItem
import com.example.data.model.TransitionType
import com.example.media.AudioRecorderManager
import com.example.media.MediaUtils
import com.example.media.RecordingState
import com.example.ui.editor.EditorToolTab
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import java.io.File

@Composable
fun PrimaryEditorToolTabs(
    activeTab: EditorToolTab,
    onTabSelected: (EditorToolTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurfaceElevated)
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 6.dp, horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToolTabItem(
            icon = Icons.Default.ContentCut,
            label = "Klip",
            isSelected = activeTab == EditorToolTab.CLIP_TOOLS,
            onClick = { onTabSelected(EditorToolTab.CLIP_TOOLS) }
        )
        ToolTabItem(
            icon = Icons.Default.Audiotrack,
            label = "Audio",
            isSelected = activeTab == EditorToolTab.AUDIO,
            onClick = { onTabSelected(EditorToolTab.AUDIO) }
        )
        ToolTabItem(
            icon = Icons.Default.TextFields,
            label = "Teks",
            isSelected = activeTab == EditorToolTab.TEXT,
            onClick = { onTabSelected(EditorToolTab.TEXT) }
        )
        ToolTabItem(
            icon = Icons.Default.EmojiEmotions,
            label = "Stiker",
            isSelected = activeTab == EditorToolTab.STICKER,
            onClick = { onTabSelected(EditorToolTab.STICKER) }
        )
        ToolTabItem(
            icon = Icons.Default.Filter,
            label = "Filter",
            isSelected = activeTab == EditorToolTab.FILTER,
            onClick = { onTabSelected(EditorToolTab.FILTER) }
        )
        ToolTabItem(
            icon = Icons.Default.Tune,
            label = "Sesuaikan",
            isSelected = activeTab == EditorToolTab.ADJUST,
            onClick = { onTabSelected(EditorToolTab.ADJUST) }
        )
        ToolTabItem(
            icon = Icons.Default.Speed,
            label = "Kecepatan",
            isSelected = activeTab == EditorToolTab.SPEED,
            onClick = { onTabSelected(EditorToolTab.SPEED) }
        )
        ToolTabItem(
            icon = Icons.Default.AspectRatio,
            label = "Kanvas",
            isSelected = activeTab == EditorToolTab.CANVAS,
            onClick = { onTabSelected(EditorToolTab.CANVAS) }
        )
        ToolTabItem(
            icon = Icons.Default.TextFields,
            label = "Subtitel",
            isSelected = activeTab == EditorToolTab.SUBTITLE,
            onClick = { onTabSelected(EditorToolTab.SUBTITLE) }
        )
        ToolTabItem(
            icon = Icons.Default.Tune,
            label = "Marker",
            isSelected = activeTab == EditorToolTab.MARKER,
            onClick = { onTabSelected(EditorToolTab.MARKER) }
        )
        ToolTabItem(
            icon = Icons.Default.Filter,
            label = "Bentuk",
            isSelected = activeTab == EditorToolTab.SHAPE,
            onClick = { onTabSelected(EditorToolTab.SHAPE) }
        )
    }
}

@Composable
fun ToolTabItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) ElectricCyan.copy(alpha = 0.18f) else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) ElectricCyan else TextSecondary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) ElectricCyan else TextSecondary
        )
    }
}

@Composable
fun ClipActionsRow(
    selectedClip: ClipEntity?,
    onSplit: () -> Unit,
    onDelete: () -> Unit,
    onDuplicate: () -> Unit,
    onRotate: () -> Unit,
    onFlipH: () -> Unit,
    onExtractAudio: () -> Unit,
    onFreezeFrame: () -> Unit,
    onOpenSpeed: () -> Unit,
    onOpenVolume: () -> Unit,
    onOpenFilter: () -> Unit,
    onOpenAdjust: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ActionButton(icon = Icons.Default.ContentCut, label = "Bagi", onClick = onSplit)
        ActionButton(icon = Icons.Default.Speed, label = "Kecepatan", onClick = onOpenSpeed)
        ActionButton(icon = Icons.Default.VolumeUp, label = "Volume", onClick = onOpenVolume)
        ActionButton(icon = Icons.Default.Filter, label = "Filter", onClick = onOpenFilter)
        ActionButton(icon = Icons.Default.Tune, label = "Sesuaikan", onClick = onOpenAdjust)
        ActionButton(icon = Icons.Default.RotateRight, label = "Putar", onClick = onRotate)
        ActionButton(icon = Icons.Default.Flip, label = "Balik H", onClick = onFlipH)
        ActionButton(icon = Icons.Default.Audiotrack, label = "Ekstrak Audio", onClick = onExtractAudio)
        ActionButton(icon = Icons.Default.AcUnit, label = "Bekukan", onClick = onFreezeFrame)
        ActionButton(icon = Icons.Default.CopyAll, label = "Gandakan", onClick = onDuplicate)
        ActionButton(icon = Icons.Default.Delete, label = "Hapus", tint = MaterialTheme.colorScheme.error, onClick = onDelete)
    }
}

@Composable
fun ActionButton(
    icon: ImageVector,
    label: String,
    tint: Color = TextPrimary,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(DarkSurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, fontSize = 10.sp, color = tint)
    }
}

@Composable
fun SpeedPanel(
    currentSpeed: Float,
    onSpeedChange: (Float) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Kecepatan Klip (${currentSpeed}x)", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        // Standard speed chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SpeedPreset.standardSpeeds.forEach { sp ->
                val isSel = (currentSpeed == sp)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSel) ElectricCyan else DarkSurfaceVariant)
                        .clickable { onSpeedChange(sp) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${sp}x",
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) Color.Black else TextPrimary,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Slider
        Slider(
            value = currentSpeed,
            onValueChange = onSpeedChange,
            valueRange = 0.25f..4.0f,
            colors = SliderDefaults.colors(
                thumbColor = ElectricCyan,
                activeTrackColor = ElectricCyan,
                inactiveTrackColor = DarkOutline
            )
        )
    }
}

@Composable
fun VolumePanel(
    currentVolume: Float,
    onVolumeChange: (Float) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Volume Klip (${(currentVolume * 100).toInt()}%)", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { onVolumeChange(0f) }) {
                Icon(Icons.Default.VolumeMute, contentDescription = "Bisukan", tint = if (currentVolume == 0f) NeonCoral else TextSecondary)
            }
            Slider(
                value = currentVolume,
                onValueChange = onVolumeChange,
                valueRange = 0f..2.0f,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = ElectricCyan, activeTrackColor = ElectricCyan)
            )
            IconButton(onClick = { onVolumeChange(1f) }) {
                Icon(Icons.Default.VolumeUp, contentDescription = "Normal", tint = TextSecondary)
            }
        }
    }
}

@Composable
fun FilterPanel(
    activeFilter: String,
    onSelectFilter: (String) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Filter Sinematik", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FilterType.entries.forEach { f ->
                val isSel = (f.name == activeFilter)
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) ElectricCyan.copy(alpha = 0.2f) else DarkSurfaceVariant)
                        .border(1.5.dp, if (isSel) ElectricCyan else DarkOutline, RoundedCornerShape(10.dp))
                        .clickable { onSelectFilter(f.name) }
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(DarkSurfaceElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.MovieFilter, contentDescription = null, tint = if (isSel) ElectricCyan else TextSecondary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = f.displayName, fontSize = 11.sp, color = if (isSel) ElectricCyan else TextPrimary)
                }
            }
        }
    }
}

@Composable
fun AdjustPanel(
    brightness: Float,
    contrast: Float,
    saturation: Float,
    onAdjustChange: (b: Float, c: Float, s: Float) -> Unit,
    onClose: () -> Unit
) {
    var b by remember(brightness) { mutableFloatStateOf(brightness) }
    var c by remember(contrast) { mutableFloatStateOf(contrast) }
    var s by remember(saturation) { mutableFloatStateOf(saturation) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Penyesuaian Warna", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        Text("Kecerahan (${b.toInt()})", fontSize = 12.sp, color = TextSecondary)
        Slider(
            value = b,
            onValueChange = { b = it; onAdjustChange(b, c, s) },
            valueRange = -100f..100f,
            colors = SliderDefaults.colors(thumbColor = ElectricCyan, activeTrackColor = ElectricCyan)
        )

        Text("Kontras (${c.toInt()})", fontSize = 12.sp, color = TextSecondary)
        Slider(
            value = c,
            onValueChange = { c = it; onAdjustChange(b, c, s) },
            valueRange = -100f..100f,
            colors = SliderDefaults.colors(thumbColor = NeonViolet, activeTrackColor = NeonViolet)
        )

        Text("Saturasi (${s.toInt()})", fontSize = 12.sp, color = TextSecondary)
        Slider(
            value = s,
            onValueChange = { s = it; onAdjustChange(b, c, s) },
            valueRange = -100f..100f,
            colors = SliderDefaults.colors(thumbColor = NeonCoral, activeTrackColor = NeonCoral)
        )
    }
}

@Composable
fun AudioPanel(
    audioRecorder: AudioRecorderManager,
    onAddAudioFile: () -> Unit,
    onVoiceOverRecorded: (file: File, durationMs: Long) -> Unit,
    onClose: () -> Unit
) {
    val recState by audioRecorder.state.collectAsState()
    val recDuration by audioRecorder.durationMs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Kelola Audio & Suara", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Pick Audio File
            Button(
                onClick = onAddAudioFile,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant, contentColor = TextPrimary),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.MusicNote, contentDescription = null, tint = ElectricCyan)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Musik / Lagu")
            }

            // Voice Over Controls
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (recState == RecordingState.RECORDING) NeonCoral.copy(alpha = 0.2f) else DarkSurfaceVariant)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                when (recState) {
                    RecordingState.IDLE, RecordingState.FINISHED -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { audioRecorder.startRecording() }
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = NeonCoral)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Rekam Suara", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    RecordingState.RECORDING -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(MediaUtils.formatTime(recDuration), color = NeonCoral, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(onClick = {
                                val file = audioRecorder.stop()
                                if (file != null) {
                                    onVoiceOverRecorded(file, recDuration)
                                }
                            }) {
                                Icon(Icons.Default.Stop, contentDescription = "Selesai", tint = NeonCoral)
                            }
                        }
                    }
                    RecordingState.PAUSED -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { audioRecorder.resume() }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Lanjut", tint = ElectricCyan)
                            }
                            IconButton(onClick = {
                                val file = audioRecorder.stop()
                                if (file != null) {
                                    onVoiceOverRecorded(file, recDuration)
                                }
                            }) {
                                Icon(Icons.Default.Stop, contentDescription = "Selesai", tint = NeonCoral)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TextAddPanel(
    onAddText: (text: String, font: String, colorHex: Long) -> Unit,
    onClose: () -> Unit
) {
    var textInput by remember { mutableStateOf("") }
    var selectedFont by remember { mutableStateOf("Roboto") }
    var selectedColor by remember { mutableStateOf(0xFFFFFFFF) }

    val fonts = listOf("Roboto", "Sans", "Serif", "Monospace")
    val colors = listOf(
        0xFFFFFFFF to "Putih",
        0xFF00E5FF to "Sian",
        0xFFFF5376 to "Koral",
        0xFF8B5CF6 to "Ungu",
        0xFFFFB300 to "Emas",
        0xFF10B981 to "Hijau",
        0xFF000000 to "Hitam"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Tambah Judul / Subtitle", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        OutlinedTextField(
            value = textInput,
            onValueChange = { textInput = it },
            placeholder = { Text("Ketik teks di sini...") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ElectricCyan,
                unfocusedBorderColor = DarkOutline
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Font chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            fonts.forEach { f ->
                val isSel = selectedFont == f
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) ElectricCyan else DarkSurfaceVariant)
                        .clickable { selectedFont = f }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = f,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) Color.Black else TextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Color circles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            colors.forEach { (colorHex, _) ->
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(colorHex.toInt()))
                        .border(
                            2.dp,
                            if (selectedColor == colorHex) ElectricCyan else DarkOutline,
                            CircleShape
                        )
                        .clickable { selectedColor = colorHex }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
            onClick = {
                if (textInput.isNotBlank()) {
                    onAddText(textInput, selectedFont, selectedColor)
                    textInput = ""
                    onClose()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color.Black),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Terapkan ke Timeline")
        }
    }
}

@Composable
fun StickerPanel(
    onAddSticker: (emoji: String) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Stiker & Badge", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StickerItem.sampleStickers.forEach { (emoji, _) ->
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurfaceVariant)
                        .clickable {
                            onAddSticker(emoji)
                            onClose()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = emoji, fontSize = 26.sp)
                }
            }
        }
    }
}

@Composable
fun CanvasRatioPanel(
    currentRatio: String,
    currentWidth: Int = 1080,
    currentHeight: Int = 1920,
    onSelectRatio: (CanvasAspectRatio) -> Unit,
    onApplyCustomSize: (width: Int, height: Int) -> Unit,
    onClose: () -> Unit
) {
    var showCustomDialog by remember { mutableStateOf(currentRatio.equals("Custom", ignoreCase = true)) }
    var customWidthStr by remember { mutableStateOf(currentWidth.toString()) }
    var customHeightStr by remember { mutableStateOf(currentHeight.toString()) }
    var isAspectLocked by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp)
            .horizontalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Aspek Rasio & Ukuran Kanvas", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        // Presets row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CanvasAspectRatio.entries.forEach { r ->
                val isSel = (r.label.equals(currentRatio, ignoreCase = true))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) ElectricCyan.copy(alpha = 0.2f) else DarkSurfaceVariant)
                        .border(1.5.dp, if (isSel) ElectricCyan else DarkOutline, RoundedCornerShape(10.dp))
                        .clickable {
                            if (r == CanvasAspectRatio.CUSTOM) {
                                showCustomDialog = true
                            } else {
                                onSelectRatio(r)
                            }
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = r.label,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) ElectricCyan else TextPrimary,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Custom Size Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(DarkSurfaceVariant)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Ukuran Kustom (1 - 8192 px)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = ElectricCyan)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = customWidthStr,
                    onValueChange = { newVal ->
                        val digits = newVal.filter { it.isDigit() }
                        customWidthStr = digits
                        if (isAspectLocked) {
                            val w = digits.toIntOrNull() ?: 1
                            val currentW = customWidthStr.toIntOrNull() ?: 1
                            val currentH = customHeightStr.toIntOrNull() ?: 1
                            val ratio = if (currentW > 0) currentH.toFloat() / currentW else 1f
                            customHeightStr = (w * ratio).toInt().coerceIn(1, 8192).toString()
                        }
                    },
                    label = { Text("Width", fontSize = 10.sp) },
                    modifier = Modifier.width(100.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyan,
                        unfocusedBorderColor = DarkOutline,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Text("×", color = TextSecondary, fontSize = 16.sp, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = customHeightStr,
                    onValueChange = { newVal ->
                        val digits = newVal.filter { it.isDigit() }
                        customHeightStr = digits
                    },
                    label = { Text("Height", fontSize = 10.sp) },
                    modifier = Modifier.width(100.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyan,
                        unfocusedBorderColor = DarkOutline,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                // Lock Aspect Ratio button
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isAspectLocked) ElectricCyan.copy(alpha = 0.25f) else DarkSurface,
                    modifier = Modifier
                        .clickable { isAspectLocked = !isAspectLocked }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (isAspectLocked) "Terkunci" else "Kunci Rasio",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isAspectLocked) ElectricCyan else TextSecondary,
                        modifier = Modifier.padding(4.dp)
                    )
                }

                Button(
                    onClick = {
                        val w = customWidthStr.toIntOrNull()?.coerceIn(1, 8192) ?: 1080
                        val h = customHeightStr.toIntOrNull()?.coerceIn(1, 8192) ?: 1920
                        onApplyCustomSize(w, h)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Terapkan", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Quick Resolution Presets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "720×1280" to (720 to 1280),
                    "1080×1920" to (1080 to 1920),
                    "1920×1080" to (1920 to 1080),
                    "1080×1080" to (1080 to 1080),
                    "2048×1080" to (2048 to 1080),
                    "3840×2160" to (3840 to 2160)
                ).forEach { (label, dim) ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkSurface)
                            .clickable {
                                customWidthStr = dim.first.toString()
                                customHeightStr = dim.second.toString()
                                onApplyCustomSize(dim.first, dim.second)
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = label, fontSize = 10.sp, color = TextSecondary)
                    }
                }
            }

            // Quick Orientation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "Portrait" to (1080 to 1920),
                    "Landscape" to (1920 to 1080),
                    "Square" to (1080 to 1080)
                ).forEach { (ori, dim) ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(NeonViolet.copy(alpha = 0.2f))
                            .clickable {
                                customWidthStr = dim.first.toString()
                                customHeightStr = dim.second.toString()
                                onApplyCustomSize(dim.first, dim.second)
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = ori, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeonViolet)
                    }
                }
            }
        }
    }
}

@Composable
fun SubtitlePanel(
    subtitles: List<com.example.data.database.entities.SubtitleEntity>,
    onAddSubtitle: (text: String) -> Unit,
    onDeleteSubtitle: (id: String) -> Unit,
    onClose: () -> Unit
) {
    var textInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Subtitel / Kapsi Otomatis", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("Tulis kalimat subtitel...", fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricCyan,
                    unfocusedBorderColor = DarkOutline,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Button(
                onClick = {
                    if (textInput.isNotBlank()) {
                        onAddSubtitle(textInput)
                        textInput = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Tambah", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        if (subtitles.isNotEmpty()) {
            Text("Daftar Subtitel:", fontSize = 11.sp, color = TextSecondary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                subtitles.forEach { sub ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceVariant,
                        modifier = Modifier.padding(2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${sub.text} (${MediaUtils.formatTime(sub.startMs)})",
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            IconButton(
                                onClick = { onDeleteSubtitle(sub.id) },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Hapus", tint = NeonCoral, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MarkerPanel(
    markers: List<com.example.data.database.entities.MarkerEntity>,
    onAddMarker: (name: String, colorHex: Long) -> Unit,
    onDeleteMarker: (id: String) -> Unit,
    onJumpToMarker: (timestampMs: Long) -> Unit,
    onClose: () -> Unit
) {
    var markerName by remember { mutableStateOf("Tanda") }
    var selectedColor by remember { mutableStateOf(0xFFFFD700) }

    val colors = listOf(
        0xFFFFD700 to "Kuning",
        0xFF00E5FF to "Sian",
        0xFFFF5376 to "Merah",
        0xFF10B981 to "Hijau",
        0xFF8B5CF6 to "Ungu"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Marker Garis Waktu", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = markerName,
                onValueChange = { markerName = it },
                placeholder = { Text("Nama marker...", fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricCyan,
                    unfocusedBorderColor = DarkOutline,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            // Color chips
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                colors.forEach { (colorVal, _) ->
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color(colorVal))
                            .border(if (selectedColor == colorVal) 2.dp else 0.dp, Color.White, CircleShape)
                            .clickable { selectedColor = colorVal }
                    )
                }
            }

            Button(
                onClick = {
                    onAddMarker(markerName.ifBlank { "Marker" }, selectedColor)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Tambah", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        if (markers.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                markers.forEach { m ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceVariant,
                        modifier = Modifier
                            .clickable { onJumpToMarker(m.timestampMs) }
                            .padding(2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(m.colorHex))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${m.name} (${MediaUtils.formatTime(m.timestampMs)})",
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                            IconButton(
                                onClick = { onDeleteMarker(m.id) },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Hapus", tint = NeonCoral, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShapePanel(
    onAddShape: (type: String, colorHex: Long) -> Unit,
    onClose: () -> Unit
) {
    val shapes = listOf("Persegi", "Lingkaran", "Panah", "Bintang", "Garis")
    val colors = listOf(
        0xFFFF5376 to "Koral",
        0xFF00E5FF to "Sian",
        0xFFFFD700 to "Emas",
        0xFF8B5CF6 to "Ungu",
        0xFFFFFFFF to "Putih"
    )
    var selectedColor by remember { mutableStateOf(0xFFFF5376) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Bentuk Geometris (Shape Overlay)", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        // Color selector
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            colors.forEach { (colorVal, name) ->
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(colorVal))
                        .border(if (selectedColor == colorVal) 2.dp else 0.dp, Color.White, CircleShape)
                        .clickable { selectedColor = colorVal }
                )
            }
        }

        // Shapes selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            shapes.forEach { shape ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant)
                        .clickable { onAddShape(shape, selectedColor) }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(text = shape, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                }
            }
        }
    }
}

@Composable
fun TransitionPanel(
    onSelectTransition: (type: String, durationMs: Long) -> Unit,
    onClose: () -> Unit
) {
    var selectedDuration by remember { mutableStateOf(500L) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Pilih Transisi", fontWeight = FontWeight.Bold, color = TextPrimary)
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
            }
        }

        // Durations
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TransitionType.durationsMs.forEach { d ->
                val isSel = (selectedDuration == d)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) NeonViolet else DarkSurfaceVariant)
                        .clickable { selectedDuration = d }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${d / 1000f}s",
                        fontSize = 11.sp,
                        color = if (isSel) Color.White else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Transition items
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TransitionType.entries.forEach { t ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurfaceVariant)
                        .clickable {
                            onSelectTransition(t.name, selectedDuration)
                            onClose()
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text(text = t.displayName, fontSize = 12.sp, color = TextPrimary)
                }
            }
        }
    }
}
