package com.example.ui.editor.components

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.database.entities.AudioClipEntity
import com.example.data.database.entities.ClipEntity
import com.example.data.database.entities.MarkerEntity
import com.example.data.database.entities.MediaEntity
import com.example.data.database.entities.SubtitleEntity
import com.example.data.database.entities.TextClipEntity
import com.example.data.database.entities.TransitionEntity
import com.example.media.MediaUtils
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun TimelineTrackView(
    clips: List<ClipEntity>,
    mediaMap: Map<String, MediaEntity>,
    textClips: List<TextClipEntity>,
    audioClips: List<AudioClipEntity>,
    transitions: List<TransitionEntity>,
    markers: List<MarkerEntity> = emptyList(),
    subtitles: List<SubtitleEntity> = emptyList(),
    selectedClipId: String?,
    playheadMs: Long,
    isPlaying: Boolean,
    onSeek: (Long) -> Unit,
    onSelectClip: (String?) -> Unit,
    onTrimClip: (newStartMs: Long, newEndMs: Long) -> Unit,
    onAddMediaClick: () -> Unit,
    onTransitionClick: (clipBeforeId: String, clipAfterId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val totalDurationMs = clips.maxOfOrNull { it.startTimeMs + it.durationMs } ?: 5000L
    val pixelsPerSecond = 80f // 80dp per second standard timeline scale
    val scrollState = rememberScrollState()

    // Smooth programmatic scroll when playhead changes during playback
    LaunchedEffect(playheadMs, isPlaying) {
        val playheadPx = with(density) { ((playheadMs / 1000f) * pixelsPerSecond).dp.toPx() }
        if (isPlaying && !scrollState.isScrollInProgress) {
            scrollState.scrollTo(playheadPx.toInt())
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .testTag("timeline_track_container")
    ) {
        val centerPadding = maxWidth / 2

        // Scrollable timeline tracks
        Column(
            modifier = Modifier
                .fillMaxSize()
                .horizontalScroll(scrollState)
        ) {
            // --- 1. Time Ruler ---
            TimeRuler(
                totalDurationMs = totalDurationMs,
                pixelsPerSecond = pixelsPerSecond,
                leftPadding = centerPadding,
                rightPadding = centerPadding,
                markers = markers,
                onSeek = onSeek,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
            )

            // --- 2. Main Video Track ---
            Row(
                modifier = Modifier
                    .padding(start = centerPadding, end = centerPadding)
                    .height(72.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                clips.forEachIndexed { index, clip ->
                    val media = mediaMap[clip.mediaId]
                    val isSelected = clip.id == selectedClipId
                    val clipWidthDp = ((clip.durationMs / 1000f) * pixelsPerSecond).dp.coerceAtLeast(44.dp)

                    VideoClipItem(
                        clip = clip,
                        media = media,
                        isSelected = isSelected,
                        widthDp = clipWidthDp,
                        onClick = { onSelectClip(if (isSelected) null else clip.id) },
                        onTrim = onTrimClip
                    )

                    // Transition button between clips
                    if (index < clips.size - 1) {
                        val nextClip = clips[index + 1]
                        val trans = transitions.firstOrNull {
                            it.clipBeforeId == clip.id && it.clipAfterId == nextClip.id
                        }
                        TransitionButton(
                            transition = trans,
                            onClick = { onTransitionClick(clip.id, nextClip.id) }
                        )
                    }
                }

                // Add Media Button at end of track
                IconButton(
                    onClick = onAddMediaClick,
                    modifier = Modifier
                        .padding(start = 12.dp)
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .border(1.dp, ElectricCyan.copy(alpha = 0.5f), CircleShape)
                        .testTag("timeline_add_media_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Tambah Media",
                        tint = ElectricCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // --- 3. Text Track ---
            if (textClips.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .padding(start = centerPadding, end = centerPadding)
                        .height(28.dp)
                ) {
                    textClips.forEach { textClip ->
                        val startDp = ((textClip.startTimeMs / 1000f) * pixelsPerSecond).dp
                        val widthDp = ((textClip.durationMs / 1000f) * pixelsPerSecond).dp.coerceAtLeast(36.dp)

                        Row(
                            modifier = Modifier
                                .offset(x = startDp)
                                .width(widthDp)
                                .height(26.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(NeonViolet.copy(alpha = 0.35f))
                                .border(1.dp, NeonViolet, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.TextFields, contentDescription = null, tint = NeonViolet, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = textClip.text,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // --- 4. Subtitles Track ---
            if (subtitles.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .padding(start = centerPadding, end = centerPadding)
                        .height(26.dp)
                ) {
                    subtitles.forEach { sub ->
                        val startDp = ((sub.startMs / 1000f) * pixelsPerSecond).dp
                        val duration = (sub.endMs - sub.startMs).coerceAtLeast(500L)
                        val widthDp = ((duration / 1000f) * pixelsPerSecond).dp.coerceAtLeast(36.dp)

                        Surface(
                            modifier = Modifier
                                .offset(x = startDp)
                                .width(widthDp)
                                .height(24.dp)
                                .clickable { onSeek(sub.startMs) },
                            shape = RoundedCornerShape(6.dp),
                            color = ElectricCyan.copy(alpha = 0.25f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = sub.text,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    color = ElectricCyan,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            // --- 5. Audio Track ---
            if (audioClips.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .padding(start = centerPadding, end = centerPadding)
                        .height(28.dp)
                ) {
                    audioClips.forEach { audio ->
                        val startDp = ((audio.startTimeMs / 1000f) * pixelsPerSecond).dp
                        val widthDp = ((audio.durationMs / 1000f) * pixelsPerSecond).dp.coerceAtLeast(36.dp)

                        Row(
                            modifier = Modifier
                                .offset(x = startDp)
                                .width(widthDp)
                                .height(26.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(NeonCoral.copy(alpha = 0.35f))
                                .border(1.dp, NeonCoral, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (audio.isVoiceOver) Icons.Default.Mic else Icons.Default.Audiotrack,
                                contentDescription = null,
                                tint = NeonCoral,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = audio.name,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }

        // --- Center Playhead Line (Stationary in Center) ---
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .width(2.5.dp)
                .fillMaxHeight()
                .background(ElectricCyan)
        ) {
            // Top cursor triangle indicator
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(ElectricCyan)
            )
        }
    }
}

@Composable
fun TimeRuler(
    totalDurationMs: Long,
    pixelsPerSecond: Float,
    leftPadding: androidx.compose.ui.unit.Dp,
    rightPadding: androidx.compose.ui.unit.Dp,
    markers: List<MarkerEntity> = emptyList(),
    onSeek: (Long) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val totalSeconds = (totalDurationMs / 1000f).toInt() + 4
    val density = LocalDensity.current

    Box(modifier = modifier) {
        Row(
            modifier = Modifier
                .padding(start = leftPadding, end = rightPadding),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (sec in 0..totalSeconds) {
                Box(
                    modifier = Modifier
                        .width(pixelsPerSecond.dp)
                        .height(24.dp)
                ) {
                    // Second tick line
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(8.dp)
                            .background(TextTertiary)
                            .align(Alignment.BottomStart)
                    )

                    // Half-second tick
                    Box(
                        modifier = Modifier
                            .offset(x = (pixelsPerSecond / 2).dp)
                            .width(1.dp)
                            .height(4.dp)
                            .background(TextTertiary.copy(alpha = 0.5f))
                            .align(Alignment.BottomStart)
                    )

                    // Time label
                    Text(
                        text = String.format("%02d:%02d", sec / 60, sec % 60),
                        fontSize = 10.sp,
                        color = TextTertiary,
                        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                    )
                }
            }
        }

        // Marker pins on top of ruler
        markers.forEach { m ->
            val markerOffsetDp = leftPadding + ((m.timestampMs / 1000f) * pixelsPerSecond).dp
            Box(
                modifier = Modifier
                    .offset(x = markerOffsetDp - 6.dp)
                    .clickable { onSeek(m.timestampMs) }
                    .padding(2.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color(m.colorHex))
                        .border(1.dp, Color.White, CircleShape)
                )
            }
        }
    }
}

@Composable
fun VideoClipItem(
    clip: ClipEntity,
    media: MediaEntity?,
    isSelected: Boolean,
    widthDp: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
    onTrim: (newStart: Long, newEnd: Long) -> Unit
) {
    var dragStartOffset by remember { mutableFloatStateOf(0f) }
    var dragEndOffset by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .width(widthDp)
            .height(68.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceVariant)
            .border(
                width = if (isSelected) 2.5.dp else 1.dp,
                color = if (isSelected) ElectricCyan else DarkOutline,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
    ) {
        // Thumbnail strip or single thumbnail
        if (media != null) {
            AsyncImage(
                model = media.uri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().alpha(0.85f)
            )
        }

        // Overlay with duration label
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(topEnd = 6.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = "${MediaUtils.formatTimeShort(clip.durationMs)} ${if (clip.speed != 1.0f) "(${clip.speed}x)" else ""}",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        // Selected Trim Handles
        if (isSelected) {
            // Left handle
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .width(14.dp)
                    .fillMaxHeight()
                    .background(ElectricCyan.copy(alpha = 0.9f))
                    .pointerInput(clip.id) {
                        detectHorizontalDragGestures { change, dragAmount ->
                            change.consume()
                            val deltaMs = (dragAmount * 20).toLong()
                            val newStart = (clip.sourceStartMs + deltaMs).coerceIn(0L, clip.sourceEndMs - 200L)
                            onTrim(newStart, clip.sourceEndMs)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(18.dp)
                        .background(Color.Black)
                )
            }

            // Right handle
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .width(14.dp)
                    .fillMaxHeight()
                    .background(ElectricCyan.copy(alpha = 0.9f))
                    .pointerInput(clip.id) {
                        detectHorizontalDragGestures { change, dragAmount ->
                            change.consume()
                            val deltaMs = (dragAmount * 20).toLong()
                            val newEnd = (clip.sourceEndMs + deltaMs).coerceAtLeast(clip.sourceStartMs + 200L)
                            onTrim(clip.sourceStartMs, newEnd)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(18.dp)
                        .background(Color.Black)
                )
            }
        }
    }
}

@Composable
fun TransitionButton(
    transition: TransitionEntity?,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .padding(horizontal = 2.dp)
            .size(24.dp)
            .clip(CircleShape)
            .background(if (transition != null) NeonViolet else DarkSurfaceElevated)
            .border(1.dp, if (transition != null) NeonViolet else DarkOutline, CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Transform,
            contentDescription = "Transisi",
            tint = if (transition != null) Color.White else TextSecondary,
            modifier = Modifier.size(13.dp)
        )
    }
}
