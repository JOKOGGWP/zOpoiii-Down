package com.example.media

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class RecordingState {
    IDLE, RECORDING, PAUSED, FINISHED
}

class AudioRecorderManager(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var currentOutputFile: File? = null
    private var timerJob: Job? = null
    private var startTime = 0L
    private var pausedDuration = 0L

    private val _state = MutableStateFlow(RecordingState.IDLE)
    val state: StateFlow<RecordingState> = _state.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    fun startRecording(): Boolean {
        try {
            val dir = File(context.cacheDir, "voiceover").apply { mkdirs() }
            val file = File(dir, "vo_${UUID.randomUUID()}.m4a")
            currentOutputFile = file

            val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            rec.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }

            recorder = rec
            _state.value = RecordingState.RECORDING
            startTime = System.currentTimeMillis()
            pausedDuration = 0L
            startTimer()
            return true
        } catch (e: Exception) {
            Log.e("AudioRecorder", "Error starting recording: ${e.message}", e)
            _state.value = RecordingState.IDLE
            return false
        }
    }

    fun pause() {
        if (_state.value == RecordingState.RECORDING && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                recorder?.pause()
                _state.value = RecordingState.PAUSED
                pausedDuration = _durationMs.value
                timerJob?.cancel()
            } catch (e: Exception) {
                Log.e("AudioRecorder", "Error pausing: ${e.message}")
            }
        }
    }

    fun resume() {
        if (_state.value == RecordingState.PAUSED && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                recorder?.resume()
                _state.value = RecordingState.RECORDING
                startTime = System.currentTimeMillis()
                startTimer()
            } catch (e: Exception) {
                Log.e("AudioRecorder", "Error resuming: ${e.message}")
            }
        }
    }

    fun stop(): File? {
        try {
            timerJob?.cancel()
            recorder?.apply {
                stop()
                release()
            }
            recorder = null
            _state.value = RecordingState.FINISHED
            return currentOutputFile
        } catch (e: Exception) {
            Log.e("AudioRecorder", "Error stopping: ${e.message}")
            _state.value = RecordingState.IDLE
            return null
        }
    }

    fun cancel() {
        timerJob?.cancel()
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (ignored: Exception) {}
        recorder = null
        currentOutputFile?.delete()
        currentOutputFile = null
        _state.value = RecordingState.IDLE
        _durationMs.value = 0L
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive && _state.value == RecordingState.RECORDING) {
                _durationMs.value = pausedDuration + (System.currentTimeMillis() - startTime)
                delay(50)
            }
        }
    }
}
