package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class MediaMetadataResult(
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val rotation: Int,
    val isVideo: Boolean,
    val thumbnailPath: String?
)

object MediaUtils {
    private const val TAG = "MediaUtils"

    fun isUriReadable(context: Context, uriString: String): Boolean {
        if (uriString.isBlank()) return false
        val uri = Uri.parse(uriString)
        return try {
            when (uri.scheme) {
                "file" -> {
                    val path = uri.path ?: return false
                    val file = File(path)
                    file.exists() && file.canRead() && file.length() > 0L
                }
                "content" -> {
                    context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                        afd.length != 0L
                    } ?: false
                }
                else -> false
            }
        } catch (e: Throwable) {
            false
        }
    }

    fun getSafeMediaFile(context: Context, projectId: String, mediaId: String): File {
        val projectMediaDir = File(context.filesDir, "projects/$projectId/media").apply { mkdirs() }
        val target = File(projectMediaDir, "healed_$mediaId.mp4")
        if (target.exists() && target.length() > 0L) {
            return target
        }
        val fallback = getOrCreateFallbackVideo(context)
        if (fallback.exists() && fallback.length() > 0L) {
            try {
                fallback.copyTo(target, overwrite = true)
                return target
            } catch (e: Exception) {
                Log.e(TAG, "Failed copying fallback to target: ${e.message}")
            }
        }
        return fallback
    }

    fun getOrCreateFallbackVideo(context: Context): File {
        val file = File(context.filesDir, "fallback_clip.mp4")
        if (file.exists() && file.length() > 1000) return file
        try {
            val width = 720
            val height = 1280
            val mime = MediaFormat.MIMETYPE_VIDEO_AVC
            val format = MediaFormat.createVideoFormat(mime, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, 500_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, 30)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val encoder = MediaCodec.createEncoderByType(mime)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = encoder.createInputSurface()
            encoder.start()
            val muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var trackIndex = -1
            var muxerStarted = false
            val bufferInfo = MediaCodec.BufferInfo()

            for (i in 0 until 60) {
                val canvas = surface.lockCanvas(null)
                canvas.drawColor(android.graphics.Color.DKGRAY)
                val paint = android.graphics.Paint().apply {
                    color = android.graphics.Color.WHITE
                    textSize = 40f
                    isAntiAlias = true
                    textAlign = android.graphics.Paint.Align.CENTER
                }
                canvas.drawText("Media Diperbarui", width / 2f, height / 2f, paint)
                surface.unlockCanvasAndPost(canvas)

                while (true) {
                    val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        trackIndex = muxer.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    } else if (outIndex >= 0) {
                        val encodedData = encoder.getOutputBuffer(outIndex)
                        if (encodedData != null && muxerStarted && bufferInfo.size > 0) {
                            muxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                        }
                        encoder.releaseOutputBuffer(outIndex, false)
                        break
                    } else {
                        break
                    }
                }
            }
            encoder.signalEndOfInputStream()
            while (true) {
                val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outIndex >= 0) {
                    val encodedData = encoder.getOutputBuffer(outIndex)
                    if (encodedData != null && muxerStarted && bufferInfo.size > 0) {
                        muxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                    }
                    encoder.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                } else {
                    break
                }
            }
            encoder.stop()
            encoder.release()
            surface.release()
            if (muxerStarted) {
                muxer.stop()
                muxer.release()
            }
            if (file.exists() && file.length() > 0) return file
        } catch (e: Throwable) {
            Log.w(TAG, "Video encoder fallback generation failed: ${e.message}")
        }
        return getOrCreateFallbackWav(context)
    }

    fun getOrCreateFallbackWav(context: Context): File {
        val file = File(context.filesDir, "fallback_clip.wav")
        if (file.exists() && file.length() > 0) return file
        try {
            val sampleRate = 44100
            val channels = 1
            val durationSeconds = 5
            val totalAudioLen = (sampleRate * channels * 2 * durationSeconds).toLong()
            val totalDataLen = totalAudioLen + 36
            val byteRate = (16 * sampleRate * channels / 8).toLong()

            FileOutputStream(file).use { out ->
                val header = ByteArray(44)
                header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte(); header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
                header[4] = (totalDataLen and 0xff).toByte()
                header[5] = ((totalDataLen shr 8) and 0xff).toByte()
                header[6] = ((totalDataLen shr 16) and 0xff).toByte()
                header[7] = ((totalDataLen shr 24) and 0xff).toByte()
                header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte(); header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()
                header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte(); header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
                header[16] = 16; header[17] = 0; header[18] = 0; header[19] = 0
                header[20] = 1; header[21] = 0
                header[22] = channels.toByte(); header[23] = 0
                header[24] = (sampleRate and 0xff).toByte()
                header[25] = ((sampleRate shr 8) and 0xff).toByte()
                header[26] = ((sampleRate shr 16) and 0xff).toByte()
                header[27] = ((sampleRate shr 24) and 0xff).toByte()
                header[28] = (byteRate and 0xff).toByte()
                header[29] = ((byteRate shr 8) and 0xff).toByte()
                header[30] = ((byteRate shr 16) and 0xff).toByte()
                header[31] = ((byteRate shr 24) and 0xff).toByte()
                header[32] = (channels * 2).toByte(); header[33] = 0
                header[34] = 16; header[35] = 0
                header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte(); header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
                header[40] = (totalAudioLen and 0xff).toByte()
                header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
                header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
                header[43] = ((totalAudioLen shr 24) and 0xff).toByte()
                out.write(header)
                val silence = ByteArray(4096)
                var bytesWritten = 0L
                while (bytesWritten < totalAudioLen) {
                    val toWrite = minOf(silence.size.toLong(), totalAudioLen - bytesWritten).toInt()
                    out.write(silence, 0, toWrite)
                    bytesWritten += toWrite
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed writing fallback wav: ${e.message}")
        }
        return file
    }

    suspend fun importMediaToProject(context: Context, projectId: String, sourceUri: Uri): Uri = withContext(Dispatchers.IO) {
        if (sourceUri.scheme == "file") {
            return@withContext sourceUri
        }
        try {
            val projectMediaDir = File(context.filesDir, "projects/$projectId/media").apply { mkdirs() }
            val mimeType = context.contentResolver.getType(sourceUri) ?: ""
            val extension = when {
                mimeType.startsWith("video/") -> "mp4"
                mimeType.startsWith("image/png") -> "png"
                mimeType.startsWith("image/") -> "jpg"
                sourceUri.toString().lowercase().endsWith(".mp4") -> "mp4"
                sourceUri.toString().lowercase().endsWith(".png") -> "png"
                sourceUri.toString().lowercase().endsWith(".jpg") -> "jpg"
                else -> "mp4"
            }
            val targetFile = File(projectMediaDir, "media_${UUID.randomUUID()}.$extension")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }
            if (targetFile.exists() && targetFile.length() > 0) {
                return@withContext Uri.fromFile(targetFile)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed importing media $sourceUri: ${e.message}", e)
        }
        sourceUri
    }

    suspend fun extractMetadata(context: Context, uri: Uri): MediaMetadataResult = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver
        val type = contentResolver.getType(uri) ?: ""
        val isImage = type.startsWith("image/") || uri.toString().lowercase().let { it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") || it.endsWith(".webp") }

        if (isImage) {
            try {
                val inputStream = if (uri.scheme == "file" && uri.path != null) {
                    java.io.FileInputStream(File(uri.path!!))
                } else {
                    contentResolver.openInputStream(uri)
                }
                inputStream?.use { stream ->
                    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeStream(stream, null, options)
                    val w = if (options.outWidth > 0) options.outWidth else 1080
                    val h = if (options.outHeight > 0) options.outHeight else 1920

                    // Save small thumbnail
                    val thumbPath = saveImageThumbnail(context, uri)
                    return@withContext MediaMetadataResult(
                        durationMs = 3000L, // Default 3s for photo in video timeline
                        width = w,
                        height = h,
                        rotation = 0,
                        isVideo = false,
                        thumbnailPath = thumbPath
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed reading image bounds: ${e.message}")
            }
            return@withContext MediaMetadataResult(3000L, 1080, 1920, 0, false, null)
        }

        // It is a video
        val retriever = MediaMetadataRetriever()
        var duration = 5000L
        var width = 1080
        var height = 1920
        var rotation = 0
        var thumbPath: String? = null

        try {
            if (uri.scheme == "file" && uri.path != null) {
                retriever.setDataSource(uri.path)
            } else {
                retriever.setDataSource(context, uri)
            }
            val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            if (!durStr.isNullOrEmpty()) {
                duration = durStr.toLongOrNull()?.coerceAtLeast(500L) ?: 5000L
            }

            val wStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val hStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            val rotStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)

            width = wStr?.toIntOrNull() ?: 1080
            height = hStr?.toIntOrNull() ?: 1920
            rotation = rotStr?.toIntOrNull() ?: 0

            // If rotated 90 or 270, swap dimensions
            if (rotation == 90 || rotation == 270) {
                val temp = width
                width = height
                height = temp
            }

            // Extract first frame thumbnail
            val frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            if (frame != null) {
                thumbPath = saveBitmapThumbnail(context, frame)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting video metadata: ${e.message}", e)
        } finally {
            try {
                retriever.release()
            } catch (ignored: Exception) {}
        }

        MediaMetadataResult(
            durationMs = duration,
            width = width,
            height = height,
            rotation = rotation,
            isVideo = true,
            thumbnailPath = thumbPath
        )
    }

    private fun saveBitmapThumbnail(context: Context, bitmap: Bitmap): String? {
        return try {
            val dir = File(context.cacheDir, "thumbnails").apply { mkdirs() }
            val file = File(dir, "thumb_${UUID.randomUUID()}.jpg")
            FileOutputStream(file).use { out ->
                val scaled = Bitmap.createScaledBitmap(
                    bitmap,
                    160,
                    (160f * (bitmap.height.toFloat() / bitmap.width)).toInt().coerceIn(90, 280),
                    true
                )
                scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }
            file.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Failed saving bitmap thumbnail: ${e.message}")
            null
        }
    }

    private fun saveImageThumbnail(context: Context, uri: Uri): String? {
        return try {
            val dir = File(context.cacheDir, "thumbnails").apply { mkdirs() }
            val file = File(dir, "thumb_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                val bm = BitmapFactory.decodeStream(input) ?: return null
                FileOutputStream(file).use { out ->
                    val scaled = Bitmap.createScaledBitmap(
                        bm,
                        160,
                        (160f * (bm.height.toFloat() / bm.width)).toInt().coerceIn(90, 280),
                        true
                    )
                    scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
                }
            }
            file.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Failed saving image thumbnail: ${e.message}")
            null
        }
    }

    fun formatTime(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        val millis = (ms % 1000) / 100
        return String.format(Locale.getDefault(), "%02d:%02d.%d", minutes, seconds, millis)
    }

    fun formatTimeShort(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
    }

    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("d MMM yyyy, HH:mm", Locale("id", "ID"))
        return sdf.format(Date(timestamp))
    }
}
