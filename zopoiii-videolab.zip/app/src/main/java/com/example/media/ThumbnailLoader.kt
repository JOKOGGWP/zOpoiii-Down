package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ThumbnailLoader {
    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = maxMemory / 8 // 1/8th of available memory for thumbs

    private val memoryCache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount / 1024
        }
    }

    suspend fun getFrameAtTime(
        context: Context,
        uri: Uri,
        timeUs: Long,
        targetWidth: Int = 120,
        targetHeight: Int = 120
    ): Bitmap? = withContext(Dispatchers.IO) {
        val cacheKey = "${uri}_$timeUs"
        memoryCache.get(cacheKey)?.let { return@withContext it }

        if (!MediaUtils.isUriReadable(context, uri.toString())) {
            return@withContext null
        }

        val retriever = MediaMetadataRetriever()
        try {
            if (uri.scheme == "file" && uri.path != null) {
                retriever.setDataSource(uri.path)
            } else {
                retriever.setDataSource(context, uri)
            }
            val frame = retriever.getScaledFrameAtTime(
                timeUs,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                targetWidth,
                targetHeight
            ) ?: retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)

            if (frame != null) {
                memoryCache.put(cacheKey, frame)
            }
            frame
        } catch (e: Throwable) {
            null
        } finally {
            try {
                retriever.release()
            } catch (ignored: Exception) {}
        }
    }

    fun clearCache() {
        memoryCache.evictAll()
    }
}
