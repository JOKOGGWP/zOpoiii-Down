package com.example.media

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.database.entities.ClipEntity
import com.example.data.database.entities.MediaEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class TimelinePlayerManager(private val context: Context) {
    private val TAG = "TimelinePlayer"

    val player: ExoPlayer = run {
        val renderersFactory = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
            .setEnableDecoderFallback(true)
        ExoPlayer.Builder(context, renderersFactory).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
        }
    }

    private var updateJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playheadMs = MutableStateFlow(0L)
    val playheadMs: StateFlow<Long> = _playheadMs.asStateFlow()

    private var currentClips: List<ClipEntity> = emptyList()
    private var currentMediaMap: Map<String, MediaEntity> = emptyMap()
    private var totalDurationMs: Long = 0L

    private var currentlyLoadedClipId: String? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                if (isPlaying) {
                    startTracking()
                } else {
                    stopTracking()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    // Check if there is a next clip
                    advanceToNextClipOrStop()
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                Log.e(TAG, "ExoPlayer playback error: ${error.errorCodeName} - ${error.message}")
                _isPlaying.value = false
                stopTracking()
            }
        })
    }

    fun setTimelineData(clips: List<ClipEntity>, mediaList: List<MediaEntity>) {
        currentClips = clips.sortedBy { it.startTimeMs }
        currentMediaMap = mediaList.associateBy { it.id }
        totalDurationMs = currentClips.maxOfOrNull { it.startTimeMs + it.durationMs } ?: 0L

        // If nothing loaded yet and clips exist, prepare first clip
        if (currentlyLoadedClipId == null && currentClips.isNotEmpty()) {
            syncPlayerWithPlayhead(_playheadMs.value, autoPlay = false)
        }
    }

    fun togglePlayPause() {
        if (player.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    fun play() {
        if (totalDurationMs == 0L) return
        if (_playheadMs.value >= totalDurationMs) {
            seekTo(0L)
        }
        syncPlayerWithPlayhead(_playheadMs.value, autoPlay = true)
    }

    fun pause() {
        player.pause()
        _isPlaying.value = false
        stopTracking()
    }

    fun seekTo(timeMs: Long) {
        val clampedTime = timeMs.coerceIn(0L, totalDurationMs.coerceAtLeast(0L))
        _playheadMs.value = clampedTime
        val wasPlaying = player.isPlaying
        syncPlayerWithPlayhead(clampedTime, autoPlay = wasPlaying)
    }

    private fun syncPlayerWithPlayhead(timelinePosMs: Long, autoPlay: Boolean) {
        val activeClip = currentClips.firstOrNull {
            timelinePosMs >= it.startTimeMs && timelinePosMs < (it.startTimeMs + it.durationMs)
        } ?: currentClips.lastOrNull()

        if (activeClip == null) {
            player.stop()
            currentlyLoadedClipId = null
            return
        }

        val media = currentMediaMap[activeClip.mediaId] ?: return
        val offsetInClipMs = (timelinePosMs - activeClip.startTimeMs).coerceAtLeast(0L)
        val sourcePositionMs = activeClip.sourceStartMs + (offsetInClipMs * activeClip.speed).toLong()

        if (currentlyLoadedClipId != activeClip.id) {
            currentlyLoadedClipId = activeClip.id
            player.stop()
            player.clearMediaItems()
            try {
                val resolvedUri: Uri = if (MediaUtils.isUriReadable(context, media.uri)) {
                    Uri.parse(media.uri)
                } else {
                    val fallbackFile = MediaUtils.getSafeMediaFile(context, media.projectId, media.id)
                    Uri.fromFile(fallbackFile)
                }
                val mediaItem = MediaItem.fromUri(resolvedUri)
                player.setMediaItem(mediaItem)
                player.playbackParameters = PlaybackParameters(activeClip.speed)
                player.prepare()
            } catch (e: Exception) {
                Log.e(TAG, "Error setting media item: ${e.message}")
            }
        } else {
            player.playbackParameters = PlaybackParameters(activeClip.speed)
        }

        player.seekTo(sourcePositionMs.coerceAtLeast(0L))
        if (autoPlay) {
            player.play()
        }
    }

    private fun startTracking() {
        updateJob?.cancel()
        updateJob = scope.launch {
            while (isActive && player.isPlaying) {
                val activeClip = currentClips.firstOrNull { it.id == currentlyLoadedClipId }
                if (activeClip != null) {
                    val currentExoPos = player.currentPosition
                    val clipLocalProgressMs = ((currentExoPos - activeClip.sourceStartMs) / activeClip.speed).toLong()
                    val calculatedPlayhead = activeClip.startTimeMs + clipLocalProgressMs

                    if (calculatedPlayhead >= activeClip.startTimeMs + activeClip.durationMs) {
                        advanceToNextClipOrStop()
                        break
                    } else {
                        _playheadMs.value = calculatedPlayhead.coerceIn(0L, totalDurationMs)
                    }
                }
                delay(25)
            }
        }
    }

    private fun advanceToNextClipOrStop() {
        val currentClipIndex = currentClips.indexOfFirst { it.id == currentlyLoadedClipId }
        if (currentClipIndex != -1 && currentClipIndex < currentClips.size - 1) {
            val nextClip = currentClips[currentClipIndex + 1]
            _playheadMs.value = nextClip.startTimeMs
            syncPlayerWithPlayhead(nextClip.startTimeMs, autoPlay = true)
        } else {
            pause()
            _playheadMs.value = totalDurationMs
        }
    }

    private fun stopTracking() {
        updateJob?.cancel()
        updateJob = null
    }

    fun release() {
        stopTracking()
        player.release()
    }
}
