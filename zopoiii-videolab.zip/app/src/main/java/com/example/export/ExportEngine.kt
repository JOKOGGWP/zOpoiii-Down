package com.example.export

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.data.database.entities.ClipEntity
import com.example.data.database.entities.MediaEntity
import com.example.data.model.ExportSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

sealed interface ExportStatus {
    object Idle : ExportStatus
    data class Exporting(val progressPercent: Int, val etaSeconds: Int) : ExportStatus
    data class Success(val outputFile: File, val savedMediaUri: Uri?) : ExportStatus
    data class Error(val errorMessage: String) : ExportStatus
    object Cancelled : ExportStatus
}

@OptIn(UnstableApi::class)
class ExportEngine(private val context: Context) {
    private val TAG = "ExportEngine"
    private var transformer: Transformer? = null
    private var progressJob: Job? = null
    private var currentOutputFile: File? = null

    private val _status = MutableStateFlow<ExportStatus>(ExportStatus.Idle)
    val status: StateFlow<ExportStatus> = _status.asStateFlow()

    suspend fun startExport(
        clips: List<ClipEntity>,
        mediaMap: Map<String, MediaEntity>,
        settings: ExportSettings
    ) = withContext(Dispatchers.Main) {
        if (clips.isEmpty()) {
            _status.value = ExportStatus.Error("Tidak ada klip video untuk diekspor.")
            return@withContext
        }

        // Check available storage space
        val totalDurationMs = clips.maxOfOrNull { it.startTimeMs + it.durationMs } ?: 5000L
        val (targetWidth, targetHeight) = settings.calculateTargetDimensions(1080, 1920)
        val estimatedSize = StorageUtils.estimateExportSizeBytes(
            totalDurationMs,
            targetWidth,
            targetHeight,
            settings.fps
        )
        val freeBytes = StorageUtils.getAvailableStorageBytes()
        if (freeBytes < estimatedSize) {
            val freeMb = freeBytes / (1024 * 1024)
            val reqMb = estimatedSize / (1024 * 1024)
            _status.value = ExportStatus.Error("Penyimpanan tidak cukup. Tersedia: ${freeMb}MB, Dibutuhkan: ~${reqMb}MB.")
            return@withContext
        }

        val outputDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val outputFile = File(outputDir, "export_${UUID.randomUUID()}.mp4")
        currentOutputFile = outputFile

        val editedMediaItems = mutableListOf<EditedMediaItem>()

        for (clip in clips.sortedBy { it.startTimeMs }) {
            val media = mediaMap[clip.mediaId] ?: continue
            val resolvedUri = if (com.example.media.MediaUtils.isUriReadable(context, media.uri)) {
                Uri.parse(media.uri)
            } else {
                val safeFile = com.example.media.MediaUtils.getSafeMediaFile(context, media.projectId, media.id)
                Uri.fromFile(safeFile)
            }

            val clippingConfig = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(clip.sourceStartMs)
                .setEndPositionMs(if (clip.sourceEndMs > clip.sourceStartMs) clip.sourceEndMs else clip.sourceStartMs + clip.durationMs)
                .build()

            val mediaItem = MediaItem.Builder()
                .setUri(resolvedUri)
                .setClippingConfiguration(clippingConfig)
                .build()

            val editedItem = EditedMediaItem.Builder(mediaItem)
                .setRemoveAudio(clip.volume == 0f)
                .build()

            editedMediaItems.add(editedItem)
        }

        if (editedMediaItems.isEmpty()) {
            _status.value = ExportStatus.Error("Tidak dapat memproses berkas media yang dipilih.")
            return@withContext
        }

        val sequence = EditedMediaItemSequence(editedMediaItems)
        val composition = Composition.Builder(sequence).build()

        val mimeVideo = if (settings.videoCodec.equals("HEVC", ignoreCase = true)) {
            MimeTypes.VIDEO_H265
        } else {
            MimeTypes.VIDEO_H264
        }

        val transformerBuilder = Transformer.Builder(context)
            .setVideoMimeType(mimeVideo)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    progressJob?.cancel()
                    // Save to user's public Movies folder
                    val savedUri = StorageUtils.saveVideoToMovies(context, outputFile, settings.customFileName)
                    _status.value = ExportStatus.Success(outputFile, savedUri)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    progressJob?.cancel()
                    Log.e(TAG, "Export failed: ${exportException.message}", exportException)
                    _status.value = ExportStatus.Error("Export gagal: ${exportException.localizedMessage ?: "Terjadi kesalahan saat encoding."}")
                }
            })

        val tf = transformerBuilder.build()
        transformer = tf
        _status.value = ExportStatus.Exporting(0, 0)

        try {
            tf.start(composition, outputFile.absolutePath)
            startProgressTracking(tf, totalDurationMs)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start transformer: ${e.message}", e)
            _status.value = ExportStatus.Error("Gagal memulai export: ${e.message}")
        }
    }

    private fun startProgressTracking(tf: Transformer, totalDurationMs: Long) {
        progressJob?.cancel()
        val startTime = System.currentTimeMillis()
        val progressHolder = ProgressHolder()

        progressJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive && _status.value is ExportStatus.Exporting) {
                val state = tf.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    val progress = progressHolder.progress
                    val elapsedSec = ((System.currentTimeMillis() - startTime) / 1000).coerceAtLeast(1)
                    val etaSec = if (progress > 5) {
                        ((elapsedSec * (100 - progress)) / progress).toInt()
                    } else {
                        (totalDurationMs / 1000).toInt()
                    }
                    _status.value = ExportStatus.Exporting(progress, etaSec)
                }
                delay(300)
            }
        }
    }

    fun cancel() {
        progressJob?.cancel()
        try {
            transformer?.cancel()
        } catch (ignored: Exception) {}
        currentOutputFile?.delete()
        _status.value = ExportStatus.Cancelled
    }

    fun reset() {
        cancel()
        _status.value = ExportStatus.Idle
    }
}
