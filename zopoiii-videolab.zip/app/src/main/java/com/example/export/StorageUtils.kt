package com.example.export

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object StorageUtils {

    fun getAvailableStorageBytes(): Long {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        return stat.availableBlocksLong * stat.blockSizeLong
    }

    fun estimateExportSizeBytes(durationMs: Long, width: Int, height: Int, fps: Int): Long {
        // Average bitrate estimate: 1080p ~ 8-10 Mbps, 720p ~ 4-5 Mbps, 480p ~ 2 Mbps
        val pixels = width * height
        val bps = when {
            pixels >= 3840 * 2160 -> 25_000_000L // 25 Mbps
            pixels >= 2560 * 1440 -> 16_000_000L // 16 Mbps
            pixels >= 1920 * 1080 -> 8_000_000L  // 8 Mbps
            pixels >= 1280 * 720 -> 4_000_000L   // 4 Mbps
            else -> 2_000_000L                   // 2 Mbps
        }
        val durationSec = (durationMs / 1000L).coerceAtLeast(1L)
        return (bps * durationSec) / 8
    }

    fun saveVideoToMovies(context: Context, sourceFile: File, customFileName: String? = null): Uri? {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val displayName = if (!customFileName.isNullOrBlank()) {
            if (customFileName.endsWith(".mp4", ignoreCase = true)) customFileName else "$customFileName.mp4"
        } else {
            "zOpoiii_VideoLab_${timeStamp}.mp4"
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/zOpoiii VideoLab")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)

            if (uri != null) {
                try {
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        FileInputStream(sourceFile).use { inputStream ->
                            inputStream.copyTo(outputStream)
                        }
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                    uri
                } catch (e: Exception) {
                    resolver.delete(uri, null, null)
                    null
                }
            } else {
                null
            }
        } else {
            // Android 9 and below
            val moviesDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "zOpoiii VideoLab")
            moviesDir.mkdirs()
            var destFile = File(moviesDir, displayName)
            var counter = 1
            while (destFile.exists()) {
                destFile = File(moviesDir, "zOpoiii_${timeStamp}_$counter.mp4")
                counter++
            }
            try {
                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }
                Uri.fromFile(destFile)
            } catch (e: Exception) {
                null
            }
        }
    }

    fun openShareSheet(context: Context, fileUri: Uri) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, fileUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Bagikan Video zOpoiii VideoLab"))
    }

    fun openVideoFile(context: Context, fileUri: Uri) {
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(fileUri, "video/mp4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(viewIntent)
        } catch (ignored: Exception) {}
    }
}
